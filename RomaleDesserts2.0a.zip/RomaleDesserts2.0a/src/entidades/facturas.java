/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author Admin
 */
public class facturas {
    
    private int id;
    private string nombre;
    private string apellido;
    private int documento;

    public facturas(int id, string nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public string getNombre() {
        return nombre;
    }

    public void setNombre(string nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "clientes_internos{" + "id=" + id + ", nombre=" + nombre + '}';
    }
    
    
}
