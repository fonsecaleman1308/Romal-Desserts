ROMALE DESSERTS - Tienda local de cheesecakes (Java Swing, sin base de datos)

ABRIR EN NETBEANS:  Archivo > Abrir proyecto > seleccionar la carpeta "RomaleDesserts" > clic en Ejecutar (F6).
Requiere JDK 11 o superior. Si NetBeans pregunta por la plataforma Java, elige tu JDK.

SIN NETBEANS:  Windows: doble clic en ejecutar.bat  |  Linux/Mac: ./ejecutar.sh  (o: java -jar dist/RomaleDesserts.jar)

Usuario administrador de prueba:  admin / admin123
Los datos (usuarios, carrito, pedidos) viven en memoria mientras la app está abierta.
Las imágenes y el logo están en src/romale/img/
