#!/bin/sh
cd "$(dirname "$0")"
java -jar dist/RomaleDesserts.jar
