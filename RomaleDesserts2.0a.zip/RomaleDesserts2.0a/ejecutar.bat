@echo off
java -jar dist\RomaleDesserts.jar
pause
