package datos;

import entidades.Reembolso;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import newpackage.Conexion;

/** Reembolsos = tabla devoluciones. El cliente solicita, Atención al cliente la recibe y el administrador resuelve. */
public final class ReembolsoDAO {
    public static final String EN_REVISION = "En revisión", APROBADA = "Aprobada", RECHAZADA = "Rechazada";

    private ReembolsoDAO() { }

    /** Crea la solicitud (estado "En revisión") y se la asigna al empleado de Atención al cliente con menos casos pendientes. */
    public static void solicitar(int idPedido, String motivo) throws SQLException {
        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT 1 FROM devoluciones WHERE id_pedido = ? AND estado IN ('En revisión', 'Aprobada') LIMIT 1")) {
                    ps.setInt(1, idPedido);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) throw new SQLException("Este pedido ya tiene un reembolso en revisión o aprobado.");
                    }
                }
                int idInterno = personalDeAtencion(c);
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO devoluciones (id_pedido, id_interno, motivo, fecha_devolucion, estado, monto_reembolsado) "
                        + "VALUES (?, ?, ?, ?, 'En revisión', 0)")) {
                    ps.setInt(1, idPedido); ps.setInt(2, idInterno);
                    ps.setString(3, motivo.length() <= 150 ? motivo : motivo.substring(0, 149) + "…");
                    ps.setString(4, LocalDate.now().toString());
                    ps.executeUpdate();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    public static List<Reembolso> listar() throws SQLException {
        String sql = "SELECT dv.id_devolucion, p.id_pedido, p.codigo_pedido, cl.nombre_completo, dv.motivo, dv.estado, "
                + "dv.fecha_devolucion, dv.monto_reembolsado, ai.nombre_completo, p.total "
                + "FROM devoluciones dv JOIN pedidos p ON p.id_pedido = dv.id_pedido "
                + "JOIN clientes cl ON cl.id_cliente = p.id_cliente "
                + "JOIN clientes_internos ai ON ai.id_interno = dv.id_interno "
                + "ORDER BY (dv.estado = 'En revisión') DESC, dv.id_devolucion DESC";
        List<Reembolso> r = new ArrayList<>();
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Reembolso x = new Reembolso();
                x.idDevolucion = rs.getInt(1); x.idPedido = rs.getInt(2); x.codigo = rs.getString(3); x.cliente = rs.getString(4);
                x.motivo = rs.getString(5); x.estado = rs.getString(6); x.fecha = rs.getString(7); x.monto = rs.getInt(8);
                x.atendio = rs.getString(9); x.totalPedido = rs.getInt(10);
                r.add(x);
            }
        }
        return r;
    }

    public static int contarPendientes() throws SQLException {
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM devoluciones WHERE estado = 'En revisión'")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /**
     * Aprueba (con el monto indicado) o rechaza una solicitud en revisión. Queda registrado quién la resolvió.
     * Si se reembolsa el pedido completo, el pedido pasa a estado "Reembolsado".
     */
    public static void resolver(int idDevolucion, int idInterno, boolean aprobar, int monto) throws SQLException {
        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try {
                int idPedido, total; String estado;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT p.id_pedido, p.total, dv.estado FROM devoluciones dv JOIN pedidos p ON p.id_pedido = dv.id_pedido "
                        + "WHERE dv.id_devolucion = ?")) {
                    ps.setInt(1, idDevolucion);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("La solicitud ya no existe.");
                        idPedido = rs.getInt(1); total = rs.getInt(2); estado = rs.getString(3);
                    }
                }
                if (!EN_REVISION.equals(estado)) throw new SQLException("Esta solicitud ya fue resuelta (" + estado + ").");
                if (aprobar && (monto <= 0 || monto > total)) throw new SQLException("El monto debe estar entre $1 y $" + total + ".");
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE devoluciones SET estado = ?, monto_reembolsado = ?, id_interno = ? WHERE id_devolucion = ?")) {
                    ps.setString(1, aprobar ? APROBADA : RECHAZADA); ps.setInt(2, aprobar ? monto : 0);
                    ps.setInt(3, idInterno); ps.setInt(4, idDevolucion);
                    ps.executeUpdate();
                }
                if (aprobar && monto >= total) {
                    try (PreparedStatement ps = c.prepareStatement("UPDATE pedidos SET estado = 'Reembolsado' WHERE id_pedido = ?")) {
                        ps.setInt(1, idPedido); ps.executeUpdate();
                    }
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    private static int personalDeAtencion(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT i.id_interno FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol AND r.nombre = 'Atención al cliente' "
                + "LEFT JOIN devoluciones d ON d.id_interno = i.id_interno AND d.estado = 'En revisión' "
                + "GROUP BY i.id_interno ORDER BY COUNT(d.id_devolucion), i.id_interno LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT i.id_interno FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol WHERE r.nombre = 'Administrador' "
                + "ORDER BY i.id_interno LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        }
        throw new SQLException("No hay personal de Atención al cliente registrado para recibir la solicitud.");
    }
}
