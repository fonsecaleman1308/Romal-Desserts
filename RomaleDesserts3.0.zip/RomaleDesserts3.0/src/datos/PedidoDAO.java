package datos;

import entidades.ItemCarrito;
import entidades.PedidoResumen;
import entidades.Usuario;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import newpackage.Conexion;

public final class PedidoDAO {

    private PedidoDAO() { }

    /**
     * Guarda el pedido completo en UNA transacción: pedidos + cheesecakes_personalizados + cheesecake_toppings
     * + cheesecake_extras + detalle_pedido. Si algo falla no queda nada a medias. Devuelve el código (PED-016...).
     */
    public static String crearPedido(Usuario u, List<ItemCarrito> items, String direccion, int envio) throws SQLException {
        if (items.isEmpty()) throw new SQLException("El carrito está vacío.");
        int subtotal = 0;
        for (ItemCarrito it : items) subtotal += it.price * it.qty;

        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try {
                int idCliente = UsuarioDAO.idClienteParaCompra(c, u, direccion);

                int idPedido;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO pedidos (codigo_pedido, id_cliente, fecha_pedido, estado, costo_envio, total, direccion_entrega, id_repartidor) "
                        + "VALUES ('TMP', ?, ?, 'Recibido', ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, idCliente);
                    ps.setString(2, LocalDate.now().toString());
                    ps.setInt(3, envio);
                    ps.setInt(4, subtotal + envio);
                    ps.setString(5, recortar(direccion, 150));
                    Integer rep = repartidorLibre(c);
                    if (rep == null) ps.setNull(6, Types.INTEGER); else ps.setInt(6, rep);
                    ps.executeUpdate();
                    idPedido = clave(ps);
                }
                String codigo = String.format(Locale.ROOT, "PED-%03d", idPedido);
                try (PreparedStatement ps = c.prepareStatement("UPDATE pedidos SET codigo_pedido = ? WHERE id_pedido = ?")) {
                    ps.setString(1, codigo); ps.setInt(2, idPedido); ps.executeUpdate();
                }

                for (ItemCarrito it : items) {
                    int idChee;
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO cheesecakes_personalizados (id_tamano, id_sabor, nombre, descripcion, precio) VALUES (?, ?, ?, ?, ?)",
                            Statement.RETURN_GENERATED_KEYS)) {
                        ps.setInt(1, it.idTamano); ps.setInt(2, it.idSabor);
                        ps.setString(3, recortar(it.name, 80)); ps.setString(4, recortar(it.detail, 200)); ps.setInt(5, it.price);
                        ps.executeUpdate();
                        idChee = clave(ps);
                    }
                    insertarRelacion(c, "INSERT INTO cheesecake_toppings (id_cheesecake, id_topping, cantidad) VALUES (?, ?, 1)", idChee, it.toppings);
                    insertarRelacion(c, "INSERT INTO cheesecake_extras (id_cheesecake, id_extra, cantidad) VALUES (?, ?, 1)", idChee, it.extras);
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO detalle_pedido (id_pedido, id_cheesecake, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)")) {
                        ps.setInt(1, idPedido); ps.setInt(2, idChee); ps.setInt(3, it.qty);
                        ps.setInt(4, it.price); ps.setInt(5, it.price * it.qty);
                        ps.executeUpdate();
                    }
                }
                c.commit();
                return codigo;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** idCliente = null devuelve todos los pedidos (panel de administrador). Incluye repartidor y último reembolso. */
    public static List<PedidoResumen> listar(Integer idCliente) throws SQLException {
        String sql = "SELECT p.id_pedido, p.codigo_pedido, cl.nombre_completo, p.fecha_pedido, p.estado, p.total, p.direccion_entrega, "
                + "(SELECT COALESCE(GROUP_CONCAT(CONCAT(d.cantidad, 'x ', ch.nombre) ORDER BY d.id_detalle SEPARATOR ', '), '') "
                + "   FROM detalle_pedido d JOIN cheesecakes_personalizados ch ON ch.id_cheesecake = d.id_cheesecake "
                + "   WHERE d.id_pedido = p.id_pedido) AS detalle, "
                + "p.id_repartidor, rp.nombre_completo, rp.telefono, "
                + "dv.id_devolucion, dv.estado, dv.motivo, dv.monto_reembolsado, dv.fecha_devolucion, ai.nombre_completo "
                + "FROM pedidos p JOIN clientes cl ON cl.id_cliente = p.id_cliente "
                + "LEFT JOIN clientes_internos rp ON rp.id_interno = p.id_repartidor "
                + "LEFT JOIN devoluciones dv ON dv.id_devolucion = (SELECT MAX(x.id_devolucion) FROM devoluciones x WHERE x.id_pedido = p.id_pedido) "
                + "LEFT JOIN clientes_internos ai ON ai.id_interno = dv.id_interno "
                + (idCliente != null ? "WHERE p.id_cliente = ? " : "")
                + "ORDER BY p.id_pedido DESC";
        List<PedidoResumen> r = new ArrayList<>();
        try (Connection c = Conexion.conectar(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (idCliente != null) ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PedidoResumen p = new PedidoResumen();
                    p.idPedido = rs.getInt(1); p.codigo = rs.getString(2); p.cliente = rs.getString(3); p.fecha = rs.getString(4);
                    p.estado = rs.getString(5); p.total = rs.getInt(6); p.direccion = rs.getString(7); p.detalle = rs.getString(8);
                    p.idRepartidor = rs.getInt(9); p.repartidor = rs.getString(10); p.repartidorTel = rs.getString(11);
                    p.idDevolucion = rs.getInt(12); p.devEstado = rs.getString(13); p.devMotivo = rs.getString(14);
                    p.devMonto = rs.getInt(15); p.devFecha = rs.getString(16); p.devAtendio = rs.getString(17);
                    r.add(p);
                }
            }
        }
        return r;
    }

    public static void asignarRepartidor(int idPedido, int idRepartidor) throws SQLException {
        try (Connection c = Conexion.conectar();
             PreparedStatement ps = c.prepareStatement("UPDATE pedidos SET id_repartidor = ? WHERE id_pedido = ?")) {
            ps.setInt(1, idRepartidor); ps.setInt(2, idPedido); ps.executeUpdate();
        }
    }

    /**
     * Elimina un pedido y TODO lo que depende de él (reembolsos, errores, detalle) y limpia también los cheesecakes
     * personalizados (con sus toppings y extras) que se crearon solo para ese pedido. Todo en una transacción.
     */
    public static void eliminar(int idPedido) throws SQLException {
        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try {
                eliminar(c, idPedido);
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    /** Elimina los pedidos finalizados (Entregado, Cancelado, Reembolsado) sin reembolsos pendientes. Devuelve cuántos borró. */
    public static int limpiarFinalizados() throws SQLException {
        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try {
                List<Integer> ids = new ArrayList<>();
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT p.id_pedido FROM pedidos p WHERE p.estado IN ('Entregado', 'Cancelado', 'Reembolsado') "
                        + "AND NOT EXISTS (SELECT 1 FROM devoluciones d WHERE d.id_pedido = p.id_pedido AND d.estado = 'En revisión')");
                     ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) ids.add(rs.getInt(1));
                }
                for (int id : ids) eliminar(c, id);
                c.commit();
                return ids.size();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        }
    }

    private static void eliminar(Connection c, int idPedido) throws SQLException {
        List<Integer> chees = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT DISTINCT id_cheesecake FROM detalle_pedido WHERE id_pedido = ?")) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) chees.add(rs.getInt(1)); }
        }
        borrar(c, "DELETE FROM devoluciones WHERE id_pedido = ?", idPedido);
        borrar(c, "DELETE FROM errores_pedido WHERE id_pedido = ?", idPedido);
        borrar(c, "DELETE FROM detalle_pedido WHERE id_pedido = ?", idPedido);
        for (int ch : chees) {
            boolean enUso;
            try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM detalle_pedido WHERE id_cheesecake = ? LIMIT 1")) {
                ps.setInt(1, ch);
                try (ResultSet rs = ps.executeQuery()) { enUso = rs.next(); }
            }
            if (!enUso) {
                borrar(c, "DELETE FROM cheesecake_toppings WHERE id_cheesecake = ?", ch);
                borrar(c, "DELETE FROM cheesecake_extras WHERE id_cheesecake = ?", ch);
                borrar(c, "DELETE FROM cheesecakes_personalizados WHERE id_cheesecake = ?", ch);
            }
        }
        borrar(c, "DELETE FROM pedidos WHERE id_pedido = ?", idPedido);
    }

    private static void borrar(Connection c, String sql, int id) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) { ps.setInt(1, id); ps.executeUpdate(); }
    }

    /** Repartidor con menos pedidos activos (Recibido, En preparación, En camino). null si no hay repartidores. */
    private static Integer repartidorLibre(Connection c) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT i.id_interno FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol AND r.nombre = 'Repartidor' "
                + "LEFT JOIN pedidos p ON p.id_repartidor = i.id_interno AND p.estado IN ('Recibido', 'En preparación', 'En camino') "
                + "GROUP BY i.id_interno ORDER BY COUNT(p.id_pedido), i.id_interno LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : null;
        }
    }

    public static void actualizarEstado(int idPedido, String estado) throws SQLException {
        try (Connection c = Conexion.conectar();
             PreparedStatement ps = c.prepareStatement("UPDATE pedidos SET estado = ? WHERE id_pedido = ?")) {
            ps.setString(1, estado); ps.setInt(2, idPedido);
            ps.executeUpdate();
        }
    }

    public static int contarPedidos() throws SQLException { return escalar("SELECT COUNT(*) FROM pedidos"); }
    public static int contarClientes() throws SQLException { return escalar("SELECT COUNT(*) FROM clientes"); }
    public static int ventasTotales() throws SQLException {
        return escalar("SELECT COALESCE(SUM(p.total), 0) - COALESCE((SELECT SUM(d.monto_reembolsado) FROM devoluciones d "
                + "JOIN pedidos x ON x.id_pedido = d.id_pedido WHERE d.estado = 'Aprobada' AND x.estado NOT IN ('Cancelado', 'Reembolsado')), 0) "
                + "FROM pedidos p WHERE p.estado NOT IN ('Cancelado', 'Reembolsado')");
    }

    // ---------- auxiliares ----------
    private static int escalar(String sql) throws SQLException {
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private static void insertarRelacion(Connection c, String sql, int idChee, List<Integer> ids) throws SQLException {
        if (ids == null || ids.isEmpty()) return;
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (int id : ids) { ps.setInt(1, idChee); ps.setInt(2, id); ps.addBatch(); }
            ps.executeBatch();
        }
    }

    private static int clave(PreparedStatement ps) throws SQLException {
        try (ResultSet rs = ps.getGeneratedKeys()) {
            if (rs.next()) return rs.getInt(1);
        }
        throw new SQLException("La base de datos no devolvió el id generado.");
    }

    private static String recortar(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }
}
