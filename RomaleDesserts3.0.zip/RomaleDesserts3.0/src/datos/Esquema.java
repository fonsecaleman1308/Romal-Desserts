package datos;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import newpackage.Conexion;

/**
 * Prepara la base de datos para el repartidor: agrega la columna pedidos.id_repartidor si todavía no existe
 * y asigna repartidores a los pedidos que ya estaban guardados. Es seguro llamarlo en cada arranque.
 */
public final class Esquema {
    private Esquema() { }

    public static void asegurar() throws SQLException {
        try (Connection c = Conexion.conectar()) {
            boolean existe;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE table_schema = DATABASE() "
                    + "AND table_name = 'pedidos' AND column_name = 'id_repartidor'");
                 ResultSet rs = ps.executeQuery()) {
                rs.next(); existe = rs.getInt(1) > 0;
            }
            if (existe) return;
            try (Statement st = c.createStatement()) {
                st.executeUpdate("ALTER TABLE pedidos ADD COLUMN id_repartidor INT NULL");
                try {
                    st.executeUpdate("ALTER TABLE pedidos ADD CONSTRAINT fk_pedidos_repartidor "
                            + "FOREIGN KEY (id_repartidor) REFERENCES clientes_internos(id_interno)");
                } catch (SQLException ignorar) { /* sin la llave foránea la columna funciona igual */ }
                List<Integer> reps = new ArrayList<>();
                try (ResultSet rs = st.executeQuery("SELECT i.id_interno FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol "
                        + "WHERE r.nombre = 'Repartidor' ORDER BY i.id_interno")) {
                    while (rs.next()) reps.add(rs.getInt(1));
                }
                for (int k = 0; k < reps.size(); k++)   // reparte los pedidos viejos entre los repartidores
                    st.executeUpdate("UPDATE pedidos SET id_repartidor = " + reps.get(k) + " WHERE MOD(id_pedido, " + reps.size() + ") = " + k);
            }
        }
    }
}
