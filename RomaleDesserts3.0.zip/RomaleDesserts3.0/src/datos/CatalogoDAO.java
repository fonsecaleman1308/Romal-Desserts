package datos;

import entidades.Opcion;
import java.sql.*;
import java.util.*;
import newpackage.Conexion;

/** Lee (y deja editar al administrador) tamaños, sabores, toppings y extras. */
public final class CatalogoDAO {

    public enum Tipo {
        TAMANOS("Tamaños", "`tamaños`", "id_tamano", "medida", "precio", ""),
        // Solo estos 4 sabores se ofrecen en la tienda (la tabla puede tener más; no se muestran)
        SABORES("Sabores (precio adicional)", "sabores", "id_sabor", "descripcion", "precio_adicional",
                " WHERE nombre IN ('Oreo', 'Maracuyá', 'Frutos rojos', 'Limón')"),
        TOPPINGS("Toppings", "toppings", "id_topping", "descripcion", "precio", ""),
        EXTRAS("Extras", "extras", "id_extra", "descripcion", "precio", "");

        public final String titulo;
        final String tabla, colId, colDetalle, colPrecio, filtro;

        Tipo(String titulo, String tabla, String colId, String colDetalle, String colPrecio, String filtro) {
            this.titulo = titulo; this.tabla = tabla; this.colId = colId; this.colDetalle = colDetalle; this.colPrecio = colPrecio; this.filtro = filtro;
        }
    }

    private CatalogoDAO() { }

    public static List<Opcion> listar(Tipo t) throws SQLException {
        List<Opcion> r = new ArrayList<>();
        String sql = "SELECT " + t.colId + ", nombre, " + t.colDetalle + ", " + t.colPrecio
                + " FROM " + t.tabla + t.filtro + " ORDER BY " + t.colId;
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) r.add(new Opcion(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4)));
        }
        return r;
    }

    public static void actualizarPrecios(Tipo t, Map<Integer, Integer> precios) throws SQLException {
        String sql = "UPDATE " + t.tabla + " SET " + t.colPrecio + " = ? WHERE " + t.colId + " = ?";
        try (Connection c = Conexion.conectar()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (Map.Entry<Integer, Integer> e : precios.entrySet()) {
                    ps.setInt(1, e.getValue()); ps.setInt(2, e.getKey()); ps.addBatch();
                }
                ps.executeBatch();
                c.commit();
            } catch (SQLException ex) {
                c.rollback();
                throw ex;
            }
        }
    }

    public static int contar(Tipo t) throws SQLException {
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + t.tabla + t.filtro)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
