package datos;

import entidades.Opcion;
import entidades.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import newpackage.Conexion;

public final class UsuarioDAO {

    /** Código que se pide para crear una cuenta de administrador desde la pantalla de registro. */
    public static final String CODIGO_ADMIN = "ROMALE2026";

    private UsuarioDAO() { }

    /** Busca primero en clientes_internos (personal/administradores) y luego en clientes. null = datos incorrectos. */
    public static Usuario autenticar(String usuario, String clave) throws SQLException {
        String hash = Seguridad.sha256(clave);
        try (Connection c = Conexion.conectar()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT i.id_interno, r.nombre, i.nombre_completo, i.correo, i.usuario, i.telefono "
                    + "FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol "
                    + "WHERE i.usuario = ? AND i.contrasena = ?")) {
                ps.setString(1, usuario); ps.setString(2, hash);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return new Usuario(rs.getInt(1), true, rs.getString(2), rs.getString(3),
                            rs.getString(4), rs.getString(5), rs.getString(6), null);
                }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT id_cliente, nombre_completo, correo, usuario, telefono, direccion "
                    + "FROM clientes WHERE usuario = ? AND contrasena = ?")) {
                ps.setString(1, usuario); ps.setString(2, hash);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return new Usuario(rs.getInt(1), false, null, rs.getString(2),
                            rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
                }
            }
        }
        return null;
    }

    /** Devuelve null si se guardó bien, o un mensaje para mostrar al usuario. */
    public static String registrarCliente(String nombre, String correo, String usuario, String clave,
                                          String telefono, String direccion) throws SQLException {
        try (Connection c = Conexion.conectar()) {
            String dup = duplicado(c, usuario, correo);
            if (dup != null) return dup;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO clientes (nombre_completo, correo, usuario, contrasena, telefono, direccion) "
                    + "VALUES (?, ?, ?, ?, ?, ?)")) {
                ps.setString(1, nombre); ps.setString(2, correo); ps.setString(3, usuario);
                ps.setString(4, Seguridad.sha256(clave));
                ps.setString(5, vacioANull(telefono)); ps.setString(6, vacioANull(direccion));
                ps.executeUpdate();
            }
        }
        return null;
    }

    /** Crea un administrador en clientes_internos (rol 'Administrador'). Exige el código de administrador. */
    public static String registrarAdministrador(String nombre, String correo, String usuario, String clave,
                                                String telefono, String codigo) throws SQLException {
        if (!CODIGO_ADMIN.equals(codigo)) return "El código de administrador es incorrecto.";
        try (Connection c = Conexion.conectar()) {
            String dup = duplicado(c, usuario, correo);
            if (dup != null) return dup;
            int idRol;
            try (PreparedStatement ps = c.prepareStatement("SELECT id_rol FROM roles WHERE nombre = 'Administrador' LIMIT 1");
                 ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return "No existe el rol Administrador en la tabla roles.";
                idRol = rs.getInt(1);
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO clientes_internos (id_rol, nombre_completo, correo, usuario, contrasena, telefono) "
                    + "VALUES (?, ?, ?, ?, ?, ?)")) {
                ps.setInt(1, idRol); ps.setString(2, nombre); ps.setString(3, correo); ps.setString(4, usuario);
                ps.setString(5, Seguridad.sha256(clave)); ps.setString(6, vacioANull(telefono));
                ps.executeUpdate();
            }
        }
        return null;
    }

    /**
     * id_cliente con el que se registra una compra. Los pedidos apuntan a la tabla clientes, así que si quien compra
     * es personal interno (p. ej. el administrador) se crea una ficha de cliente con los mismos datos la primera vez.
     */
    public static int idClienteParaCompra(Connection c, Usuario u, String direccion) throws SQLException {
        if (!u.interno) return u.id;
        int existente = buscarIdCliente(c, u.usuario);
        if (existente > 0) return existente;
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO clientes (nombre_completo, correo, usuario, contrasena, telefono, direccion) "
                + "SELECT nombre_completo, correo, usuario, contrasena, telefono, ? FROM clientes_internos WHERE id_interno = ?",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, vacioANull(direccion)); ps.setInt(2, u.id);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("No se pudo crear la ficha de cliente para " + u.usuario);
    }

    /** id_cliente del usuario para consultar su historial; -1 si todavía no ha comprado nada. */
    public static int idCliente(Usuario u) throws SQLException {
        if (!u.interno) return u.id;
        try (Connection c = Conexion.conectar()) {
            return buscarIdCliente(c, u.usuario);
        }
    }

    private static int buscarIdCliente(Connection c, String usuario) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT id_cliente FROM clientes WHERE usuario = ? LIMIT 1")) {
            ps.setString(1, usuario);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    private static String duplicado(Connection c, String usuario, String correo) throws SQLException {
        if (existe(c, "usuario", usuario)) return "Ese usuario ya existe. Elige otro.";
        if (existe(c, "correo", correo)) return "Ese correo ya está registrado.";
        return null;
    }

    private static boolean existe(Connection c, String columna, String valor) throws SQLException {
        for (String tabla : new String[]{"clientes", "clientes_internos"}) {
            try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM " + tabla + " WHERE " + columna + " = ? LIMIT 1")) {
                ps.setString(1, valor);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return true;
                }
            }
        }
        return false;
    }

    /** Empleados con rol Repartidor (id, nombre y teléfono) para poder asignarlos a los pedidos. */
    public static List<Opcion> listarRepartidores() throws SQLException {
        List<Opcion> r = new ArrayList<>();
        try (Connection c = Conexion.conectar(); PreparedStatement ps = c.prepareStatement(
                "SELECT i.id_interno, i.nombre_completo, i.telefono FROM clientes_internos i JOIN roles r ON r.id_rol = i.id_rol "
                + "WHERE r.nombre = 'Repartidor' ORDER BY i.nombre_completo");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) r.add(new Opcion(rs.getInt(1), rs.getString(2), rs.getString(3), 0));
        }
        return r;
    }

    private static String vacioANull(String s) { return s == null || s.trim().isEmpty() ? null : s.trim(); }
}
