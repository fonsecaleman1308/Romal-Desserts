package datos;

import entidades.Factura;
import java.sql.*;
import java.util.Locale;
import newpackage.Conexion;

/** Lee de la base de datos todo lo necesario para imprimir o enviar la factura de un pedido. */
public final class FacturaDAO {
    private FacturaDAO() { }

    public static Factura cargarPorCodigo(String codigoPedido) throws SQLException {
        try (Connection c = Conexion.conectar()) {
            Factura f = null; int idPedido = 0;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT p.id_pedido, p.codigo_pedido, p.fecha_pedido, p.estado, p.costo_envio, p.total, p.direccion_entrega, "
                    + "cl.nombre_completo, cl.correo, cl.telefono, rp.nombre_completo "
                    + "FROM pedidos p JOIN clientes cl ON cl.id_cliente = p.id_cliente "
                    + "LEFT JOIN clientes_internos rp ON rp.id_interno = p.id_repartidor WHERE p.codigo_pedido = ?")) {
                ps.setString(1, codigoPedido);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        f = new Factura(); idPedido = rs.getInt(1);
                        f.numero = String.format(Locale.ROOT, "FAC-%05d", idPedido);
                        f.codigoPedido = rs.getString(2); f.fecha = rs.getString(3); f.estado = rs.getString(4);
                        f.envio = rs.getInt(5); f.total = rs.getInt(6); f.direccion = rs.getString(7);
                        f.cliente = rs.getString(8); f.correo = rs.getString(9); f.telefono = rs.getString(10); f.repartidor = rs.getString(11);
                    }
                }
            }
            if (f == null) throw new SQLException("No se encontró el pedido " + codigoPedido + ".");
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT ch.nombre, ch.descripcion, d.cantidad, d.precio_unitario, d.subtotal "
                    + "FROM detalle_pedido d JOIN cheesecakes_personalizados ch ON ch.id_cheesecake = d.id_cheesecake "
                    + "WHERE d.id_pedido = ? ORDER BY d.id_detalle")) {
                ps.setInt(1, idPedido);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Factura.Linea l = new Factura.Linea();
                        l.nombre = rs.getString(1); l.descripcion = rs.getString(2); l.cantidad = rs.getInt(3);
                        l.precioUnitario = rs.getInt(4); l.subtotal = rs.getInt(5);
                        f.lineas.add(l); f.subtotal += l.subtotal;
                    }
                }
            }
            if (f.lineas.isEmpty()) f.subtotal = f.total - f.envio;
            return f;
        }
    }
}
