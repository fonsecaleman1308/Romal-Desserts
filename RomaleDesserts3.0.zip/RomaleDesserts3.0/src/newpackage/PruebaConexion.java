package newpackage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/** Ejecuta esta clase (Shift+F6) para comprobar que Java se conecta a la base de datos. */
public class PruebaConexion {
    public static void main(String[] args) {
        try (Connection c = Conexion.conectar(); Statement st = c.createStatement()) {
            System.out.println("CONEXIÓN EXITOSA con la base de datos.");
            String[] tablas = {"clientes", "clientes_internos", "pedidos", "detalle_pedido", "sabores"};
            for (String t : tablas) {
                try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + t)) {
                    rs.next();
                    System.out.println(" - " + t + ": " + rs.getInt(1) + " registros");
                }
            }
        } catch (Exception e) {
            System.out.println("ERROR DE CONEXIÓN: " + e.getMessage());
        }
    }
}
