package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Conexión a MySQL / MariaDB (XAMPP, WAMP, MySQL Server...).
 * Cada llamada a conectar() abre una conexión nueva; los DAO la cierran con try-with-resources.
 */
public class Conexion {

    // ===== CONFIGURACIÓN: cambia estos valores si tu servidor es distinto =====
    private static final String HOST    = "localhost";
    private static final String PUERTO  = "3306";
    private static final String BD      = "basededatosrd";
    private static final String USUARIO = "root";
    private static final String CLAVE   = "";   // XAMPP suele venir con la clave vacía: ""
    // ==========================================================================

    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    private Conexion() { }

    public static Connection conectar() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            throw new SQLException("No se encontró el driver de MySQL. Copia mysql-connector-java-8.0.17.jar "
                    + "en la carpeta lib del proyecto (o agrégalo en Libraries).", e);
        }
        String url = "jdbc:mysql://" + HOST + ":" + PUERTO + "/" + BD
                + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8";
        return DriverManager.getConnection(url, USUARIO, CLAVE);
    }

    /** Devuelve null si la conexión funciona, o el mensaje de error si falla. */
    public static String probar() {
        try (Connection c = conectar()) {
            return null;
        } catch (SQLException e) {
            return e.getMessage();
        }
    }
}
