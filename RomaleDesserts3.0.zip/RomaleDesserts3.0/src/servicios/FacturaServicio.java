package servicios;

import entidades.Factura;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Locale;

/** Une todo: genera el PDF de la factura, lo guarda en la carpeta "facturas" y lo envía por correo al cliente. */
public final class FacturaServicio {
    private FacturaServicio() { }

    public static byte[] pdf(Factura f) throws IOException {
        BufferedImage logo = null;
        try { logo = javax.imageio.ImageIO.read(FacturaServicio.class.getResource("/romale/img/logo.png")); } catch (Exception ignorar) { }
        return FacturaPDF.generar(f, logo);
    }

    /** Guarda facturas/FAC-00016.pdf (dentro de la carpeta desde donde se ejecuta la aplicación). */
    public static File guardarPdf(Factura f) throws IOException {
        File dir = new File("facturas"); dir.mkdirs();
        File out = new File(dir, f.numero + ".pdf");
        Files.write(out.toPath(), pdf(f));
        return out;
    }

    public static void enviarCorreo(Factura f) throws IOException {
        Correo.enviar(f.correo, "Tu factura " + f.numero + " - Romale Desserts", html(f), f.numero + ".pdf", pdf(f));
    }

    private static String m(int n) { return String.format(Locale.US, "$%,d", n); }
    private static String e(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    /** Cuerpo del correo (HTML con estilos en línea, compatible con Gmail/Outlook). */
    public static String html(Factura f) {
        StringBuilder r = new StringBuilder();
        for (Factura.Linea l : f.lineas)
            r.append("<tr><td style='padding:10px 12px;border-bottom:1px solid #e6e9f0'><b>").append(e(l.nombre)).append("</b><br><span style='color:#6b7385;font-size:12px'>")
             .append(e(l.descripcion)).append("</span></td><td align='center' style='border-bottom:1px solid #e6e9f0'>").append(l.cantidad)
             .append("</td><td align='right' style='border-bottom:1px solid #e6e9f0'>").append(m(l.precioUnitario))
             .append("</td><td align='right' style='padding-right:12px;border-bottom:1px solid #e6e9f0'><b>").append(m(l.subtotal)).append("</b></td></tr>");
        return "<div style='background:#f3f4f8;padding:24px;font-family:Segoe UI,Arial,sans-serif;color:#1a1f2e'>"
            + "<div style='max-width:640px;margin:auto;background:#ffffff;border-radius:14px;overflow:hidden'>"
            + "<div style='background:#05050a;padding:22px 26px;border-bottom:4px solid #ff4da6'>"
            + "<div style='font-size:26px;font-weight:bold;color:#ff4da6;letter-spacing:1px'>ROMALE</div>"
            + "<div style='font-size:11px;letter-spacing:4px;color:#38e1ff'>D E S S E R T S</div></div>"
            + "<div style='padding:26px'><h2 style='margin:0 0 6px 0'>¡Gracias por tu compra, " + e(f.cliente) + "!</h2>"
            + "<p style='margin:0 0 18px 0;color:#4a5163'>Adjuntamos tu factura <b>" + e(f.numero) + "</b> del pedido <b>" + e(f.codigoPedido) + "</b> (" + e(f.fecha) + ").</p>"
            + "<table width='100%' cellspacing='0' cellpadding='0' style='font-size:14px'>"
            + "<tr style='background:#171b33;color:#ffffff;font-size:12px'><td style='padding:10px 12px'>DESCRIPCIÓN</td><td align='center'>CANT.</td><td align='right'>VALOR UNIT.</td><td align='right' style='padding-right:12px'>SUBTOTAL</td></tr>"
            + r + "</table>"
            + "<table align='right' cellspacing='0' cellpadding='4' style='margin-top:14px;font-size:14px'>"
            + "<tr><td style='color:#6b7385'>Subtotal</td><td align='right'>" + m(f.subtotal) + "</td></tr>"
            + "<tr><td style='color:#6b7385'>Envío</td><td align='right'>" + m(f.envio) + "</td></tr>"
            + "<tr><td style='font-size:16px'><b>Total</b></td><td align='right' style='font-size:18px;color:#e0197f'><b>" + m(f.total) + "</b></td></tr></table>"
            + "<div style='clear:both'></div>"
            + "<p style='margin:26px 0 4px 0;color:#4a5163;font-size:13px'><b>Entrega en:</b> " + e(f.direccion) + "<br><b>Repartidor:</b> " + e(f.repartidor == null ? "Por asignar" : f.repartidor) + "</p>"
            + "<p style='margin:14px 0 0 0;color:#8a90a0;font-size:12px'>Si tienes algún problema con tu pedido, puedes solicitar un reembolso desde la sección «Mis pedidos» de la aplicación.</p>"
            + "</div></div></div>";
    }
}
