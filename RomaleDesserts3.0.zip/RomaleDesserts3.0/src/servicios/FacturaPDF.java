package servicios;

import entidades.Factura;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Genera la factura en PDF (A4) sin librerías externas: escribe el PDF directamente con fuentes estándar Helvetica. */
public final class FacturaPDF {
    private static final double W = 595, H = 842, M = 40;
    private static final Charset WIN = Charset.forName("windows-1252");
    // anchos de Helvetica (milésimas de em) para los caracteres ASCII 32..126
    private static final int[] AW = {278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
        556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015,
        667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611,
        278, 278, 278, 469, 556, 333,
        556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500,
        334, 260, 334, 584};
    private static final double[] INK = {0.10, 0.12, 0.18}, GRAY = {0.42, 0.46, 0.55}, WHITE = {1, 1, 1},
            PINK = {1, 0.30, 0.65}, CYAN = {0.22, 0.88, 1}, NAVY = {0.09, 0.11, 0.20}, LINE = {0.88, 0.90, 0.94};

    private FacturaPDF() { }

    /** Una página: acumula operadores PDF. Las coordenadas y se dan "desde arriba" y se convierten aquí. */
    private static final class Page {
        final StringBuilder sb = new StringBuilder();
        void rect(double x, double top, double w, double h, double[] c) {
            sb.append(f(c[0])).append(' ').append(f(c[1])).append(' ').append(f(c[2])).append(" rg ")
              .append(f(x)).append(' ').append(f(H - top - h)).append(' ').append(f(w)).append(' ').append(f(h)).append(" re f\n");
        }
        void line(double x1, double x2, double top, double[] c) {
            sb.append(f(c[0])).append(' ').append(f(c[1])).append(' ').append(f(c[2])).append(" RG 0.8 w ")
              .append(f(x1)).append(' ').append(f(H - top)).append(" m ").append(f(x2)).append(' ').append(f(H - top)).append(" l S\n");
        }
        void text(double x, double top, String s, double size, boolean bold, double[] c) {
            sb.append("BT ").append(f(c[0])).append(' ').append(f(c[1])).append(' ').append(f(c[2])).append(" rg /")
              .append(bold ? "F2" : "F1").append(' ').append(f(size)).append(" Tf 1 0 0 1 ").append(f(x)).append(' ').append(f(H - top))
              .append(" Tm ").append(lit(s)).append(" Tj ET\n");
        }
        void right(double xr, double top, String s, double size, boolean bold, double[] c) { text(xr - width(s, size, bold), top, s, size, bold, c); }
        void center(double xc, double top, String s, double size, boolean bold, double[] c) { text(xc - width(s, size, bold) / 2, top, s, size, bold, c); }
        void image(double x, double top, double w, double h) {
            sb.append("q ").append(f(w)).append(" 0 0 ").append(f(h)).append(' ').append(f(x)).append(' ').append(f(H - top - h)).append(" cm /Im1 Do Q\n");
        }
    }

    public static byte[] generar(Factura fa, BufferedImage logo) throws IOException {
        byte[] jpg = logo == null ? null : aJpeg(logo);
        double ratio = logo == null ? 1 : logo.getWidth() / (double) logo.getHeight();
        List<Page> pages = new ArrayList<>();
        Page p = new Page(); pages.add(p);

        // ---- cabecera
        p.rect(0, 0, W, 112, new double[]{0.012, 0.012, 0.02});
        p.rect(0, 112, W / 2, 3, PINK); p.rect(W / 2, 112, W / 2, 3, CYAN);
        double bx = M;
        if (jpg != null) { double lh = 80; p.image(M, 16, lh * ratio, lh); bx = M + lh * ratio + 14; }
        p.text(bx, 60, "ROMALE", 28, true, PINK); p.text(bx, 78, "D E S S E R T S", 9, true, CYAN);
        p.right(W - M, 46, "FACTURA DE VENTA", 17, true, WHITE);
        p.right(W - M, 66, "No. " + fa.numero, 12, true, CYAN);
        p.right(W - M, 84, "Fecha: " + fa.fecha, 10, false, new double[]{0.8, 0.83, 0.9});

        // ---- datos del cliente y del pedido
        double yl = 146, yr = 146;
        p.text(M, yl, "FACTURADO A", 8, true, GRAY); yl += 16;
        p.text(M, yl, nz(fa.cliente), 12, true, INK); yl += 15;
        if (!nz(fa.correo).isEmpty()) { p.text(M, yl, fa.correo, 10, false, INK); yl += 13; }
        if (!nz(fa.telefono).isEmpty()) { p.text(M, yl, "Tel. " + fa.telefono, 10, false, INK); yl += 13; }
        if (!nz(fa.direccion).isEmpty()) {
            p.text(M, yl, "Entrega en:", 8, true, GRAY); yl += 12;
            for (String s : wrap(fa.direccion, 10, false, 250)) { p.text(M, yl, s, 10, false, INK); yl += 13; }
        }
        double rx = 340;
        p.text(rx, yr, "DATOS DEL PEDIDO", 8, true, GRAY); yr += 16;
        String[][] dp = {{"Pedido", fa.codigoPedido}, {"Estado", fa.estado}, {"Repartidor", fa.repartidor == null ? "Por asignar" : fa.repartidor}};
        for (String[] r : dp) { p.text(rx, yr, r[0] + ":", 10, false, GRAY); p.text(rx + 70, yr, nz(r[1]), 10, true, INK); yr += 15; }

        // ---- tabla de productos
        double y = Math.max(yl, yr) + 16;
        y = cabeceraTabla(p, y);
        for (Factura.Linea l : fa.lineas) {
            List<String> nom = wrap(nz(l.nombre), 10, true, 290);
            List<String> des = wrap(nz(l.descripcion), 8.5, false, 290);
            if (des.size() > 3) { des = new ArrayList<>(des.subList(0, 3)); des.set(2, des.get(2) + "…"); }
            double rh = 12 + nom.size() * 13 + des.size() * 11 + 8;
            if (y + rh > 760) { p = nuevaPagina(pages, fa, jpg != null, ratio); y = cabeceraTabla(p, 86); }
            double ty = y + 16;
            for (String s : nom) { p.text(M + 10, ty, s, 10, true, INK); ty += 13; }
            for (String s : des) { p.text(M + 10, ty - 1, s, 8.5, false, GRAY); ty += 11; }
            p.center(372, y + 16, "" + l.cantidad, 10, false, INK);
            p.right(480, y + 16, money(l.precioUnitario), 10, false, INK);
            p.right(W - M - 10, y + 16, money(l.subtotal), 10, true, INK);
            y += rh; p.line(M, W - M, y, LINE);
        }

        // ---- totales
        if (y + 130 > 790) { p = nuevaPagina(pages, fa, jpg != null, ratio); y = 90; }
        y += 18; double tx = 340, tr = W - M - 10;
        p.text(tx, y, "Subtotal", 10.5, false, GRAY); p.right(tr, y, money(fa.subtotal), 10.5, false, INK); y += 17;
        p.text(tx, y, "Envío", 10.5, false, GRAY); p.right(tr, y, money(fa.envio), 10.5, false, INK); y += 12;
        p.rect(tx - 8, y, W - M - tx + 8, 34, NAVY);
        p.rect(tx - 8, y, 4, 34, PINK);
        p.text(tx + 6, y + 22, "TOTAL A PAGAR", 10, true, WHITE); p.right(tr, y + 23, money(fa.total), 15, true, CYAN);
        p.text(M, y + 8, "¡Gracias por elegir Romale Desserts!", 12, true, INK);
        double yn = y + 24;
        for (String s : wrap("Tu pedido se prepara con ingredientes frescos y se entrega en la dirección indicada.", 9, false, 270)) { p.text(M, yn, s, 9, false, GRAY); yn += 12; }

        // ---- pie de página y ensamblado
        for (int i = 0; i < pages.size(); i++) {
            Page pg = pages.get(i);
            pg.line(M, W - M, 806, LINE);
            pg.text(M, 822, "Romale Desserts · Bogotá, Colombia · Comprobante generado automáticamente", 8, false, GRAY);
            pg.right(W - M, 822, "Página " + (i + 1) + " de " + pages.size(), 8, false, GRAY);
        }
        return ensamblar(pages, jpg, logo);
    }

    private static Page nuevaPagina(List<Page> pages, Factura fa, boolean hayLogo, double ratio) {
        Page p = new Page(); pages.add(p);
        p.rect(0, 0, W, 60, new double[]{0.012, 0.012, 0.02}); p.rect(0, 60, W, 3, PINK);
        p.text(M, 38, "ROMALE DESSERTS", 16, true, PINK);
        p.right(W - M, 38, "Factura " + fa.numero + " (continuación)", 11, true, WHITE);
        return p;
    }
    private static double cabeceraTabla(Page p, double y) {
        p.rect(M, y, W - 2 * M, 24, NAVY);
        p.text(M + 10, y + 16, "DESCRIPCIÓN", 8.5, true, WHITE); p.center(372, y + 16, "CANT.", 8.5, true, WHITE);
        p.right(480, y + 16, "VALOR UNIT.", 8.5, true, WHITE); p.right(W - M - 10, y + 16, "SUBTOTAL", 8.5, true, WHITE);
        return y + 24;
    }

    private static byte[] ensamblar(List<Page> pages, byte[] jpg, BufferedImage logo) throws IOException {
        List<byte[]> objs = new ArrayList<>();          // objeto n = índice n-1
        int firstPage = jpg != null ? 6 : 5;
        StringBuilder kids = new StringBuilder();
        for (int i = 0; i < pages.size(); i++) kids.append(firstPage + 2 * i).append(" 0 R ");
        objs.add(a("<< /Type /Catalog /Pages 2 0 R >>"));
        objs.add(a("<< /Type /Pages /Kids [ " + kids + "] /Count " + pages.size() + " >>"));
        objs.add(a("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"));
        objs.add(a("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"));
        if (jpg != null) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            o.write(a("<< /Type /XObject /Subtype /Image /Width " + logo.getWidth() + " /Height " + logo.getHeight()
                    + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " + jpg.length + " >>\nstream\n"));
            o.write(jpg); o.write(a("\nendstream"));
            objs.add(o.toByteArray());
        }
        String res = "/Resources << /Font << /F1 3 0 R /F2 4 0 R >>" + (jpg != null ? " /XObject << /Im1 5 0 R >>" : "") + " >>";
        for (int i = 0; i < pages.size(); i++) {
            int content = firstPage + 2 * i + 1;
            objs.add(a("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] " + res + " /Contents " + content + " 0 R >>"));
            byte[] c = pages.get(i).sb.toString().getBytes(StandardCharsets.ISO_8859_1);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            o.write(a("<< /Length " + c.length + " >>\nstream\n")); o.write(c); o.write(a("\nendstream"));
            objs.add(o.toByteArray());
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(a("%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n"));
        int[] off = new int[objs.size()];
        for (int i = 0; i < objs.size(); i++) {
            off[i] = out.size();
            out.write(a((i + 1) + " 0 obj\n")); out.write(objs.get(i)); out.write(a("\nendobj\n"));
        }
        int xref = out.size();
        StringBuilder x = new StringBuilder("xref\n0 " + (objs.size() + 1) + "\n0000000000 65535 f \n");
        for (int o : off) x.append(String.format(Locale.ROOT, "%010d 00000 n \n", o));
        x.append("trailer\n<< /Size ").append(objs.size() + 1).append(" /Root 1 0 R >>\nstartxref\n").append(xref).append("\n%%EOF\n");
        out.write(a(x.toString()));
        return out.toByteArray();
    }

    // ---------- utilidades ----------
    private static byte[] a(String s) { return s.getBytes(StandardCharsets.ISO_8859_1); }
    private static String f(double v) { return String.format(Locale.ROOT, "%.2f", v); }
    private static String nz(String s) { return s == null ? "" : s; }
    static String money(int n) { return String.format(Locale.US, "$%,d", n); }

    /** Cadena PDF en codificación WinAnsi (acentos y ñ incluidos). */
    private static String lit(String s) {
        StringBuilder o = new StringBuilder("(");
        for (byte b : s.getBytes(WIN)) {
            int v = b & 0xFF;
            if (v == '(' || v == ')' || v == '\\') o.append('\\').append((char) v);
            else if (v < 32 || v > 126) o.append(String.format(Locale.ROOT, "\\%03o", v));
            else o.append((char) v);
        }
        return o.append(')').toString();
    }
    static double width(String s, double size, boolean bold) {
        double w = 0;
        for (char ch : s.toCharArray()) {
            char c = ch;
            if (c < 32 || c > 126) { String n = Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD); c = n.charAt(0); }
            w += (c >= 32 && c <= 126) ? AW[c - 32] : 556;
        }
        return w * size / 1000.0 * (bold ? 1.05 : 1.0);
    }
    private static List<String> wrap(String text, double size, boolean bold, double max) {
        List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
        for (String word : text.trim().split("\\s+")) {
            if (word.isEmpty()) continue;
            String t = cur.length() == 0 ? word : cur + " " + word;
            if (width(t, size, bold) <= max || cur.length() == 0) { cur = new StringBuilder(t); }
            else { out.add(cur.toString()); cur = new StringBuilder(word); }
        }
        if (cur.length() > 0) out.add(cur.toString());
        if (out.isEmpty()) out.add("");
        return out;
    }
    private static byte[] aJpeg(BufferedImage src) throws IOException {
        BufferedImage rgb = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_RGB);
        java.awt.Graphics2D g = rgb.createGraphics(); g.setColor(java.awt.Color.BLACK); g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight()); g.drawImage(src, 0, 0, null); g.dispose();
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        if (!javax.imageio.ImageIO.write(rgb, "jpg", o)) throw new IOException("No se pudo codificar el logo.");
        return o.toByteArray();
    }
}
