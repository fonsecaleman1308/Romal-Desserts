package servicios;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Locale;
import java.util.UUID;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * Envío de correos por SMTP con autenticación (AUTH LOGIN), sin librerías externas.
 *
 * ===== CONFIGURACIÓN: edita estos valores =====
 * Gmail: activa la verificación en 2 pasos y crea una "Contraseña de aplicación"
 *        (cuenta de Google > Seguridad > Contraseñas de aplicaciones). Esa clave de 16 letras va en CLAVE.
 *        NO uses la contraseña normal de tu cuenta.
 * Outlook/Hotmail: HOST "smtp-mail.outlook.com", PUERTO 587.
 */
public final class Correo {
    public static String HOST = "smtp.gmail.com";
    public static int PUERTO = 465;            // 465 = SSL, 587 = STARTTLS, otro = sin cifrado (solo para pruebas locales)
    public static String USUARIO = "";         // tu correo completo, p. ej. romaledesserts@gmail.com
    public static String CLAVE = "";           // contraseña de aplicación
    public static String NOMBRE = "Romale Desserts";
    // ==============================================

    private Correo() { }

    public static boolean configurado() { return !USUARIO.trim().isEmpty() && !CLAVE.trim().isEmpty(); }

    /** Envía un correo HTML con un archivo adjunto. Lanza IOException con un mensaje claro si algo falla. */
    public static void enviar(String para, String asunto, String html, String nombreAdjunto, byte[] adjunto) throws IOException {
        if (!configurado()) throw new IOException("El envío de correos no está configurado (archivo servicios/Correo.java).");
        if (para == null || !para.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) throw new IOException("El correo del cliente no es válido: " + para);
        Socket sock = new Socket();
        try {
            sock.connect(new InetSocketAddress(HOST, PUERTO), 15000); sock.setSoTimeout(20000);
            if (PUERTO == 465) sock = tls(sock);
            Dialogo d = new Dialogo(sock);
            d.esperar(220);
            d.cmd("EHLO romale-desserts", 250);
            if (PUERTO == 587) { d.cmd("STARTTLS", 220); sock = tls(sock); d = new Dialogo(sock); d.cmd("EHLO romale-desserts", 250); }
            try { d.cmd("AUTH LOGIN", 334); d.cmd(b64(USUARIO), 334); d.cmd(b64(CLAVE), 235); }
            catch (IOException e) {
                throw new IOException(e.getMessage() + "\nRevisa USUARIO y CLAVE en servicios/Correo.java (en Gmail se usa una contraseña de aplicación).");
            }
            d.cmd("MAIL FROM:<" + USUARIO + ">", 250);
            d.cmd("RCPT TO:<" + para + ">", 250, 251);
            d.cmd("DATA", 354);
            d.cuerpo(mensaje(para, asunto, html, nombreAdjunto, adjunto));
            d.esperar(250);
            try { d.cmd("QUIT", 221); } catch (IOException ignorar) { }
        } catch (java.net.UnknownHostException e) {
            throw new IOException("No se encontró el servidor de correo " + HOST + ". Revisa tu conexión a internet.");
        } catch (java.net.SocketTimeoutException | java.net.ConnectException e) {
            throw new IOException("No se pudo conectar con " + HOST + ":" + PUERTO + " (" + e.getMessage() + "). Revisa tu internet o el firewall.");
        } finally {
            try { sock.close(); } catch (IOException ignorar) { }
        }
    }

    private static Socket tls(Socket s) throws IOException {
        SSLSocket t = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(s, HOST, PUERTO, true);
        t.startHandshake();
        return t;
    }
    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String enc(String s) { return "=?UTF-8?B?" + b64(s) + "?="; }

    private static String mensaje(String para, String asunto, String html, String nombreAdj, byte[] adj) {
        String b = "----=_Romale_" + UUID.randomUUID().toString().replace("-", "");
        Base64.Encoder mime = Base64.getMimeEncoder(76, new byte[]{'\r', '\n'});
        StringBuilder m = new StringBuilder();
        m.append("From: ").append(enc(NOMBRE)).append(" <").append(USUARIO).append(">\r\n");
        m.append("To: <").append(para).append(">\r\n");
        m.append("Subject: ").append(enc(asunto)).append("\r\n");
        m.append("Date: ").append(DateTimeFormatter.RFC_1123_DATE_TIME.withLocale(Locale.US).format(ZonedDateTime.now())).append("\r\n");
        m.append("Message-ID: <").append(UUID.randomUUID()).append("@romale-desserts>\r\n");
        m.append("MIME-Version: 1.0\r\n");
        m.append("Content-Type: multipart/mixed; boundary=\"").append(b).append("\"\r\n\r\n");
        m.append("--").append(b).append("\r\n");
        m.append("Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        m.append(mime.encodeToString(html.getBytes(StandardCharsets.UTF_8))).append("\r\n");
        if (adj != null) {
            m.append("--").append(b).append("\r\n");
            m.append("Content-Type: application/pdf; name=\"").append(nombreAdj).append("\"\r\n");
            m.append("Content-Transfer-Encoding: base64\r\n");
            m.append("Content-Disposition: attachment; filename=\"").append(nombreAdj).append("\"\r\n\r\n");
            m.append(mime.encodeToString(adj)).append("\r\n");
        }
        m.append("--").append(b).append("--\r\n");
        return m.toString();
    }

    /** Conversación línea a línea con el servidor SMTP. */
    private static final class Dialogo {
        final BufferedReader in; final BufferedWriter out;
        Dialogo(Socket s) throws IOException {
            in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.ISO_8859_1));
            out = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.ISO_8859_1));
        }
        void cmd(String c, int... validos) throws IOException { out.write(c + "\r\n"); out.flush(); esperar(validos); }
        void cuerpo(String m) throws IOException { out.write(m); out.write("\r\n.\r\n"); out.flush(); }
        void esperar(int... validos) throws IOException {
            String linea;
            do {
                linea = in.readLine();
                if (linea == null) throw new IOException("El servidor de correo cerró la conexión.");
            } while (linea.length() > 3 && linea.charAt(3) == '-');
            int codigo;
            try { codigo = Integer.parseInt(linea.substring(0, 3)); } catch (RuntimeException e) { throw new IOException("Respuesta inesperada del servidor: " + linea); }
            for (int v : validos) if (v == codigo) return;
            throw new IOException("El servidor de correo respondió: " + linea);
        }
    }
}
