package entidades;

import java.util.ArrayList;
import java.util.List;

/** Datos completos de una factura de venta (se arma desde pedidos, clientes y detalle_pedido). */
public class Factura {
    public String numero, codigoPedido, fecha, estado, cliente, correo, telefono, direccion, repartidor;
    public int envio, subtotal, total;
    public List<Linea> lineas = new ArrayList<>();

    public static class Linea {
        public String nombre, descripcion;
        public int cantidad, precioUnitario, subtotal;
    }
}
