package entidades;

/** Persona que inició sesión: puede venir de la tabla clientes o de clientes_internos. */
public class Usuario {
    public final int id;            // id_cliente o id_interno según 'interno'
    public final boolean interno;   // true = personal de Romale (tabla clientes_internos)
    public final String rol;        // nombre del rol (solo internos)
    public final String nombre, correo, usuario, telefono, direccion;

    public Usuario(int id, boolean interno, String rol, String nombre, String correo,
                   String usuario, String telefono, String direccion) {
        this.id = id; this.interno = interno; this.rol = rol; this.nombre = nombre;
        this.correo = correo; this.usuario = usuario; this.telefono = telefono; this.direccion = direccion;
    }

    public boolean isAdmin() {
        return interno && "Administrador".equalsIgnoreCase(rol);
    }
}
