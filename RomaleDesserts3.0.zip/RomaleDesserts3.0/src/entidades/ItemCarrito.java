package entidades;

import java.util.ArrayList;
import java.util.List;

/** Un cheesecake dentro del carrito, con los ids necesarios para guardarlo en la base de datos. */
public class ItemCarrito {
    public String name, img, detail;
    public int price, qty = 1;
    public int idTamano, idSabor;
    public List<Integer> toppings = new ArrayList<>(), extras = new ArrayList<>();

    public ItemCarrito(String name, String img, int price, String detail, int idTamano, int idSabor,
                       List<Integer> toppings, List<Integer> extras) {
        this.name = name; this.img = img; this.price = price; this.detail = detail;
        this.idTamano = idTamano; this.idSabor = idSabor;
        this.toppings = toppings; this.extras = extras;
    }
}
