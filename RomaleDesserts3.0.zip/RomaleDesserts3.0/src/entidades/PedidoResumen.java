package entidades;

/** Pedido listo para mostrar en pantalla (historial del cliente o panel del administrador). */
public class PedidoResumen {
    public int idPedido, total;
    public String codigo, cliente, fecha, detalle, estado, direccion;
    // repartidor asignado (null = por asignar)
    public int idRepartidor;
    public String repartidor, repartidorTel;
    // último reembolso del pedido (idDevolucion = 0 si no hay ninguno)
    public int idDevolucion, devMonto;
    public String devEstado, devMotivo, devFecha, devAtendio;
}
