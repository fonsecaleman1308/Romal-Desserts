package entidades;

/** Fila de catálogo: tamaño, sabor, topping o extra (id, nombre, texto descriptivo y precio). */
public class Opcion {
    public final int id;
    public final String nombre, detalle;
    public final int precio;

    public Opcion(int id, String nombre, String detalle, int precio) {
        this.id = id; this.nombre = nombre; this.detalle = detalle == null ? "" : detalle; this.precio = precio;
    }

    @Override public String toString() { return nombre; }
}
