package entidades;

/** Solicitud de reembolso (tabla devoluciones) con los datos del pedido y de quien la atiende. */
public class Reembolso {
    public int idDevolucion, idPedido, monto, totalPedido;
    public String codigo, cliente, motivo, estado, fecha, atendio;
}
