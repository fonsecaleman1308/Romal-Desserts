package romale;

import datos.*;
import entidades.*;
import servicios.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.font.TextAttribute;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.SQLException;
import java.util.*;
import java.util.List;

/** Romale Desserts - tienda de cheesecakes (Swing + MySQL). Los datos viven en la base de datos basededatosrd. */
public class Main {
    // ===== PALETA FUTURISTA (los nombres PINK y GOLD se conservan para no tocar la lógica) =====
    static final Color BG = new Color(7, 9, 18), CARD = new Color(17, 21, 38), ROW2 = new Color(22, 27, 48), FIELD = new Color(11, 14, 28),
            PINK = new Color(255, 77, 166),      // acento principal (rosa neón)
            GOLD = new Color(56, 225, 255),      // acento secundario (cian neón, antes dorado)
            VIOLET = new Color(139, 92, 255),
            WHITE = new Color(236, 240, 255), MUTED = new Color(139, 148, 176), EDGE = new Color(52, 62, 105);
    static final int ENVIO = 5000;

    static List<ItemCarrito> cart = new ArrayList<>();
    static Usuario user = null;     // sesión actual (cliente o administrador)
    static String current = "catalog";

    static JFrame frame; static CardLayout cl = new CardLayout(); static JPanel content = new JPanel(cl);
    static Map<String, JPanel> views = new LinkedHashMap<>(); static Map<String, Btn> nav = new LinkedHashMap<>();
    static Map<String, Runnable> builders = new HashMap<>();

    // ---------- utilidades de UI ----------
    static String money(int n) { return String.format(Locale.US, "$%,d", n); }
    static Font F(int st, int s) { return new Font("Segoe UI", st, s); }
    static Font S(int st, int s) {   // fuente de títulos: sans negrita con letras ligeramente separadas
        Map<TextAttribute, Object> a = new HashMap<>(); a.put(TextAttribute.TRACKING, 0.03f);
        return new Font("Segoe UI", st == 0 ? Font.PLAIN : Font.BOLD, s).deriveFont(a);
    }
    static JLabel L(String t, Font f, Color c) { JLabel l = new JLabel(t); l.setFont(f); l.setForeground(c); return l; }
    static void aa(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }
    /** Imagen con esquinas redondeadas. */
    static ImageIcon img(String n, int w, int h) {
        try {
            Image i = javax.imageio.ImageIO.read(Main.class.getResource("/romale/img/" + n + ".png"));
            BufferedImage o = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB); Graphics2D g = o.createGraphics(); aa(g);
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.setComposite(AlphaComposite.Src); g.setColor(Color.WHITE); int r = Math.min(w, h) / 5;
            g.fill(new RoundRectangle2D.Float(0, 0, w, h, r, r));
            g.setComposite(AlphaComposite.SrcAtop); g.drawImage(i, 0, 0, w, h, null); g.dispose();
            return new ImageIcon(o);
        } catch (Exception e) { return new ImageIcon(new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB)); }
    }
    static JPanel col() { JPanel p = new JPanel(); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); p.setOpaque(false); return p; }
    static Component gap(int h) { return Box.createVerticalStrut(h); }
    static <T extends JComponent> T ctr(T c) { c.setAlignmentX(0.5f); return c; }

    /** Barra de desplazamiento delgada y moderna. */
    static class Slim extends javax.swing.plaf.basic.BasicScrollBarUI {
        protected void configureScrollBarColors() { thumbColor = new Color(70, 80, 125); trackColor = BG; }
        static JButton zero() { JButton b = new JButton(); b.setPreferredSize(new Dimension(0, 0)); b.setMinimumSize(new Dimension(0, 0)); b.setMaximumSize(new Dimension(0, 0)); return b; }
        protected JButton createDecreaseButton(int o) { return zero(); }
        protected JButton createIncreaseButton(int o) { return zero(); }
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) { }
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) return; Graphics2D g2 = (Graphics2D) g.create(); aa(g2);
            g2.setColor(isThumbRollover() ? new Color(255, 77, 166, 210) : new Color(110, 120, 170, 170));
            g2.fillRoundRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 8, 8); g2.dispose();
        }
        public Dimension getPreferredSize(JComponent c) { return new Dimension(10, 10); }
    }
    static JScrollPane sp(Component c) {
        JScrollPane s = new JScrollPane(c); s.setBorder(null); s.setOpaque(false); s.getViewport().setOpaque(false);
        s.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
        s.getVerticalScrollBar().setUnitIncrement(16); s.getVerticalScrollBar().setUI(new Slim()); s.getHorizontalScrollBar().setUI(new Slim());
        s.getVerticalScrollBar().setOpaque(false); return s;
    }
    static <T extends AbstractButton> T sty(T b) { b.setOpaque(false); b.setForeground(WHITE); b.setFont(F(0, 13)); b.setFocusPainted(false); return b; }
    static Border fb(Color line) { return new CompoundBorder(new LineBorder(line, 1, true), new EmptyBorder(9, 12, 9, 12)); }
    static JTextField tf(JTextField t) {
        t.setBackground(FIELD); t.setForeground(WHITE); t.setCaretColor(GOLD); t.setSelectionColor(PINK); t.setFont(F(0, 14)); t.setBorder(fb(EDGE));
        t.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) { t.setBorder(fb(GOLD)); }
            public void focusLost(java.awt.event.FocusEvent e) { t.setBorder(fb(EDGE)); } });
        t.setPreferredSize(new Dimension(340, 44)); t.setMaximumSize(new Dimension(340, 44)); t.setAlignmentX(0.5f); return t;
    }
    static JTextField field(JPanel c, String label, boolean pass) {
        c.add(ctr(L(label, F(0, 12), MUTED))); c.add(gap(4));
        JTextField t = tf(pass ? new JPasswordField() : new JTextField()); c.add(t); c.add(gap(10)); return t;
    }
    static void combo(JComboBox<?> c) {
        c.setBackground(FIELD); c.setForeground(WHITE); c.setFont(F(0, 13));
        c.setUI(new javax.swing.plaf.basic.BasicComboBoxUI() {
            protected JButton createArrowButton() {
                javax.swing.plaf.basic.BasicArrowButton b = new javax.swing.plaf.basic.BasicArrowButton(SwingConstants.SOUTH, FIELD, FIELD, GOLD, FIELD);
                b.setBorder(new EmptyBorder(0, 0, 0, 0)); return b; }
            public void paintCurrentValueBackground(Graphics g, Rectangle r, boolean hasFocus) { g.setColor(FIELD); g.fillRect(r.x, r.y, r.width, r.height); }
        });
        c.setBorder(new LineBorder(EDGE, 1, true)); c.setOpaque(true);
    }

    /** Texto con degradado rosa -> cian (títulos). */
    static class GL extends JLabel {
        GL(String t, Font f) { super(t); setFont(f); setForeground(WHITE); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); g2.setFont(getFont()); FontMetrics fm = g2.getFontMetrics();
            g2.setPaint(new GradientPaint(0, 0, PINK, Math.max(fm.stringWidth(getText()), 1), 0, GOLD));
            g2.drawString(getText(), 0, (getHeight() - fm.getHeight()) / 2 + fm.getAscent()); g2.dispose();
        }
    }
    static JPanel header(String t, String sub) {
        JPanel h = col(); h.setBorder(new EmptyBorder(20, 30, 10, 30));
        JLabel a = new GL(t, S(1, 34)), b = L(sub, F(0, 14), MUTED); a.setAlignmentX(0); b.setAlignmentX(0);
        JPanel acc = new JPanel() { protected void paintComponent(Graphics g) { Graphics2D g2 = (Graphics2D) g.create(); aa(g2);
            g2.setPaint(new GradientPaint(0, 0, PINK, getWidth(), 0, GOLD)); g2.fillRoundRect(0, 0, getWidth(), getHeight(), 4, 4); g2.dispose(); } };
        acc.setOpaque(false); acc.setPreferredSize(new Dimension(70, 4)); acc.setMaximumSize(new Dimension(70, 4)); acc.setAlignmentX(0);
        h.add(a); h.add(gap(2)); h.add(acc); h.add(gap(8)); h.add(b);
        JPanel w = new JPanel(new BorderLayout()); w.setOpaque(false); w.add(h, BorderLayout.WEST); return w;
    }
    static JPanel centered(JComponent c) { JPanel w = new JPanel(new GridBagLayout()); w.setOpaque(false); w.add(c); return w; }
    static RP card(int pad) { RP c = new RP(CARD, 26); c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS)); c.setBorder(new EmptyBorder(pad, pad, pad, pad)); return c; }
    static void say(String m) { JOptionPane.showMessageDialog(frame, m, "Romale Desserts", JOptionPane.PLAIN_MESSAGE, img("logo", 48, 48)); }
    static void empty(JPanel p, String msg, String btn, String to) {
        RP c = card(34); c.add(ctr(L(msg, S(1, 22), WHITE))); c.add(gap(16)); Btn b = new Btn(btn, PINK, false);
        b.addActionListener(e -> go(to)); c.add(ctr(b)); p.add(centered(c), BorderLayout.CENTER);
    }
    static JTable table(DefaultTableModel m) {
        JTable t = new JTable(m); t.setBackground(CARD); t.setForeground(WHITE); t.setRowHeight(36); t.setFont(F(0, 13));
        t.setShowGrid(false); t.setIntercellSpacing(new Dimension(0, 0)); t.setFillsViewportHeight(true);
        t.setSelectionBackground(new Color(190, 45, 125)); t.setSelectionForeground(WHITE);
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, sel, false, r, c); setBorder(new EmptyBorder(0, 12, 0, 12));
                setBackground(sel ? new Color(190, 45, 125) : r % 2 == 0 ? CARD : ROW2); setForeground(WHITE); return this; } });
        JTableHeader h = t.getTableHeader(); h.setReorderingAllowed(false); h.setPreferredSize(new Dimension(10, 38));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tb, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(tb, v, false, false, r, c); setText(String.valueOf(v).toUpperCase());
                setBackground(new Color(26, 32, 58)); setForeground(GOLD); setFont(F(1, 11)); setHorizontalAlignment(LEFT);
                setBorder(new CompoundBorder(new MatteBorder(0, 0, 2, 0, new Color(255, 77, 166, 160)), new EmptyBorder(0, 12, 0, 12))); return this; } });
        return t;
    }
    static JScrollPane tsp(JTable t) {
        JScrollPane s = new JScrollPane(t); s.setBorder(new MatteBorder(1, 1, 1, 1, new Color(40, 48, 85))); s.getViewport().setBackground(CARD);
        s.getVerticalScrollBar().setUI(new Slim()); return s;
    }

    /** Tarjeta con degradado sutil y borde neón. */
    static class RP extends JPanel {
        Color bg; int r;
        RP(Color bg, int r) { this.bg = bg; this.r = r; setOpaque(false); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); int w = getWidth() - 1, h = Math.max(getHeight() - 1, 1);
            g2.setPaint(new GradientPaint(0, 0, new Color(Math.min(255, bg.getRed() + 14), Math.min(255, bg.getGreen() + 16), Math.min(255, bg.getBlue() + 26)), 0, h, bg));
            g2.fillRoundRect(0, 0, w, h, r, r);
            g2.setStroke(new BasicStroke(1.2f)); g2.setPaint(new GradientPaint(0, 0, new Color(56, 225, 255, 120), w, h, new Color(255, 77, 166, 120)));
            g2.drawRoundRect(0, 0, w, h, r, r); g2.dispose(); super.paintComponent(g);
        }
    }
    /** Botón: píldora con degradado (normal) o elemento de menú con subrayado de neón (flat). */
    static class Btn extends JButton {
        static final Color NAV = new Color(200, 206, 232);
        Color c; boolean flat, active;
        Btn(String t, Color c, boolean flat) {
            super(t); this.c = c; this.flat = flat; setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false); setOpaque(false);
            setFont(F(1, flat ? 13 : 14)); setBorder(new EmptyBorder(flat ? 9 : 11, flat ? 13 : 24, flat ? 9 : 11, flat ? 13 : 24));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); setForeground(flat ? NAV : WHITE);
        }
        void setActive(boolean a) { active = a; setForeground(a ? WHITE : NAV); repaint(); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); int w = getWidth(), h = getHeight();
            boolean hov = getModel().isRollover(), prs = getModel().isPressed();
            if (flat) {
                if (hov && !active) { g2.setColor(new Color(255, 255, 255, 22)); g2.fillRoundRect(0, 0, w - 1, h - 1, 16, 16); }
                if (active) {
                    g2.setColor(new Color(255, 77, 166, 30)); g2.fillRoundRect(0, 0, w - 1, h - 1, 16, 16);
                    g2.setPaint(new GradientPaint(10, 0, PINK, Math.max(w - 10, 11), 0, GOLD)); g2.fillRoundRect(10, h - 5, Math.max(w - 20, 1), 3, 3, 3);
                }
            } else {
                boolean main = c.equals(PINK);
                Color a = main ? PINK : c.brighter(), b = main ? VIOLET : c.darker();
                if (hov) { a = a.brighter(); b = b.brighter(); }
                if (prs) { a = a.darker(); b = b.darker(); }
                g2.setPaint(new GradientPaint(0, 0, a, w, 0, b)); g2.fillRoundRect(0, 0, w - 1, h - 1, h, h);
                g2.setStroke(new BasicStroke(1f)); g2.setColor(new Color(255, 255, 255, hov ? 90 : 40)); g2.drawRoundRect(0, 0, w - 1, h - 1, h, h);
            }
            g2.dispose(); super.paintComponent(g);
        }
    }

    // ---------- componentes animados (catálogo y personalizar) ----------
    static final Map<String, BufferedImage> RAW = new HashMap<>();
    static BufferedImage raw(String n) {
        if (!RAW.containsKey(n)) {
            try { RAW.put(n, javax.imageio.ImageIO.read(Main.class.getResource("/romale/img/" + n + ".png"))); }
            catch (Exception e) { RAW.put(n, null); }
        }
        return RAW.get(n);
    }
    static String fit(String s, FontMetrics fm, int max) {
        if (fm.stringWidth(s) <= max) return s;
        while (s.length() > 1 && fm.stringWidth(s + "…") > max) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    /** Imagen con transición suave (fundido), zoom lento tipo "Ken Burns", zoom al pasar el mouse y textos encima. */
    static class FadeImg extends JComponent {
        BufferedImage a, b; float t = 1f, k = 0f, ka = 0f, hz = 0f; boolean live = true, contain = false; int rad = 26;
        String title = "", sub = "", tag = "";
        final javax.swing.Timer tm = new javax.swing.Timer(30, e -> tick());
        FadeImg(String first) { a = raw(first); setOpaque(false); }
        void setImage(String n) {
            BufferedImage nb = raw(n); BufferedImage cur = (b != null) ? b : a;
            if (nb == cur) return;
            if (b != null) a = b;
            ka = k; b = nb; t = 0f; k = 0f; repaint();
        }
        void tick() {
            if (!isShowing()) return;
            if (b != null) { t = Math.min(1f, t + 0.07f); if (t >= 1f) { a = b; b = null; } }
            if (k < 1f) k = Math.min(1f, k + 0.0035f);
            repaint();
        }
        public void addNotify() { super.addNotify(); if (live) tm.start(); }
        public void removeNotify() { tm.stop(); super.removeNotify(); }
        void cover(Graphics2D g2, BufferedImage im, int w, int h, float kk) {
            if (im == null) return;
            float fx = w / (float) im.getWidth(), fy = h / (float) im.getHeight();
            float sc = (contain ? Math.min(fx, fy) : Math.max(fx, fy)) * (1f + 0.08f * kk + 0.10f * hz);
            int dw = Math.round(im.getWidth() * sc), dh = Math.round(im.getHeight() * sc);
            g2.drawImage(im, (w - dw) / 2, (h - dh) / 2, dw, dh, null);
        }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            int w = getWidth(), h = getHeight();
            Shape oldClip = g2.getClip(); g2.clip(new RoundRectangle2D.Float(0, 0, w, h, rad, rad)); g2.setColor(contain ? new Color(2, 2, 3) : FIELD); g2.fillRect(0, 0, w, h);
            cover(g2, a, w, h, b == null ? k : ka);
            if (b != null) { g2.setComposite(AlphaComposite.SrcOver.derive(t)); cover(g2, b, w, h, k); g2.setComposite(AlphaComposite.SrcOver); }
            g2.setPaint(new GradientPaint(0, h * 0.5f, new Color(7, 9, 18, 0), 0, h, new Color(7, 9, 18, title.isEmpty() ? 110 : 225)));
            g2.fillRect(0, 0, w, h);
            if (!title.isEmpty()) {
                g2.setFont(S(1, 22)); g2.setColor(WHITE); g2.drawString(title, 20, h - 42);
                g2.setFont(F(0, 12)); g2.setColor(new Color(200, 206, 232)); g2.drawString(sub, 20, h - 20);
            }
            if (!tag.isEmpty()) {
                g2.setFont(F(1, 13)); FontMetrics fm = g2.getFontMetrics(); int tw = fm.stringWidth(tag) + 22, x = w - tw - 12, y = 12;
                g2.setColor(new Color(7, 9, 18, 205)); g2.fillRoundRect(x, y, tw, 28, 28, 28);
                g2.setColor(new Color(56, 225, 255, 170)); g2.drawRoundRect(x, y, tw, 28, 28, 28);
                g2.setColor(GOLD); g2.drawString(tag, x + 11, y + 19);
            }
            g2.setClip(oldClip); g2.setStroke(new BasicStroke(1.3f));
            g2.setPaint(new GradientPaint(0, 0, new Color(56, 225, 255, 130), w, h, new Color(255, 77, 166, 130)));
            g2.drawRoundRect(0, 0, w - 1, h - 1, rad, rad); g2.dispose();
        }
    }

    /** Puntos indicadores del carrusel (clic para ir a un sabor). */
    static class Dots extends JComponent {
        int n, cur; final java.util.function.IntConsumer on;
        Dots(int n, java.util.function.IntConsumer on) {
            this.n = n; this.on = on; setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new java.awt.event.MouseAdapter() { public void mouseClicked(java.awt.event.MouseEvent e) {
                int i = e.getX() / 24; if (i >= 0 && i < Dots.this.n) Dots.this.on.accept(i); } });
        }
        public Dimension getPreferredSize() { return new Dimension(n * 24 + 4, 16); }
        public Dimension getMaximumSize() { return getPreferredSize(); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2);
            for (int i = 0; i < n; i++) {
                int x = i * 24 + 2;
                if (i == cur) { g2.setPaint(new GradientPaint(x, 0, PINK, x + 18, 0, GOLD)); g2.fillRoundRect(x, 4, 18, 8, 8, 8); }
                else { g2.setColor(new Color(90, 100, 150)); g2.fillOval(x + 5, 4, 8, 8); }
            }
            g2.dispose();
        }
    }

    /** Contador animado: el precio "sube" o "baja" suavemente hasta el nuevo valor. */
    static class NumAnim {
        final JLabel lab; double cur; int target; final javax.swing.Timer t;
        NumAnim(JLabel l, int start) {
            lab = l; cur = target = start; lab.setText(money(start));
            t = new javax.swing.Timer(16, e -> {
                cur += (target - cur) * 0.2;
                if (Math.abs(target - cur) < 1) { cur = target; ((javax.swing.Timer) e.getSource()).stop(); }
                lab.setText(money((int) Math.round(cur)));
            });
        }
        void set(int v) { target = v; if (!t.isRunning()) t.start(); }
        void jump() { t.stop(); cur = target; lab.setText(money(target)); }
    }

    /** Botón seleccionable tipo "chip" (con miniatura opcional), usado para sabores, tamaños, extras y toppings. */
    static class Chip extends JToggleButton {
        final String title, sub; final boolean multi; final Image thumb;
        Chip(String title, String sub, String icon, boolean multi) {
            this.title = title; this.sub = sub; this.multi = multi; thumb = icon == null ? null : img(icon, 44, 44).getImage();
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false); setFocusable(false); setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); setToolTipText(title);
            setPreferredSize(new Dimension(thumb != null ? 170 : 120, thumb != null ? 62 : 54));
        }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); int w = getWidth(), h = getHeight(); boolean sel = isSelected(), hov = getModel().isRollover();
            if (sel) g2.setPaint(new GradientPaint(0, 0, new Color(255, 77, 166, 95), w, h, new Color(139, 92, 255, 95)));
            else g2.setColor(hov ? new Color(34, 41, 72) : ROW2);
            g2.fillRoundRect(0, 0, w - 1, h - 1, 16, 16);
            g2.setStroke(new BasicStroke(sel ? 1.8f : 1f)); g2.setColor(sel ? GOLD : hov ? new Color(100, 112, 170) : EDGE);
            g2.drawRoundRect(0, 0, w - 1, h - 1, 16, 16);
            int x0 = 14;
            if (thumb != null) { g2.drawImage(thumb, 9, (h - 44) / 2, null); x0 = 9 + 44 + 10; }
            int avail = w - x0 - (multi ? 30 : 10);
            g2.setFont(F(1, 12)); g2.setColor(WHITE); g2.drawString(fit(title, g2.getFontMetrics(), avail), x0, h / 2 - 3);
            g2.setFont(F(0, 11)); g2.setColor(sel ? GOLD : MUTED); g2.drawString(fit(sub, g2.getFontMetrics(), avail), x0, h / 2 + 13);
            if (multi && sel) {
                g2.setColor(GOLD); g2.fillOval(w - 25, 9, 15, 15);
                g2.setColor(BG); g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(w - 21, 17, w - 18, 20); g2.drawLine(w - 18, 20, w - 14, 13);
            }
            g2.dispose();
        }
    }

    /** Tarjeta de sabor del catálogo: al pasar el mouse la foto hace zoom y el borde se ilumina. */
    static class ProdCard extends RP {
        final FadeImg im; float hov = 0f, target = 0f; final javax.swing.Timer tm;
        ProdCard(Opcion s, int precio, Runnable onAdd) {
            super(CARD, 26); setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); setBorder(new EmptyBorder(12, 12, 14, 12));
            im = new FadeImg(imgFor(s.nombre)); im.live = false; im.tag = money(precio);
            im.setPreferredSize(new Dimension(170, 170)); im.setMaximumSize(new Dimension(Integer.MAX_VALUE, 170)); im.setAlignmentX(0.5f);
            JLabel n = ctr(L(s.nombre, S(1, 21), WHITE));
            JLabel d = ctr(L("<html><div style='text-align:center;width:150px'>" + s.detalle + "</div></html>", F(0, 12), MUTED));
            Btn b = ctr(new Btn("Agregar al carrito", PINK, false)); b.addActionListener(e -> onAdd.run());
            add(im); add(gap(12)); add(n); add(gap(6)); add(d); add(gap(14)); add(b);
            tm = new javax.swing.Timer(16, e -> {
                hov += (target - hov) * 0.25f;
                if (Math.abs(target - hov) < 0.01f) { hov = target; ((javax.swing.Timer) e.getSource()).stop(); }
                im.hz = hov; im.repaint(); repaint();
            });
            java.awt.event.MouseAdapter ma = new java.awt.event.MouseAdapter() {
                void upd() { SwingUtilities.invokeLater(() -> { target = getMousePosition(true) != null ? 1f : 0f; if (!tm.isRunning()) tm.start(); }); }
                public void mouseEntered(java.awt.event.MouseEvent e) { upd(); }
                public void mouseExited(java.awt.event.MouseEvent e) { upd(); }
            };
            addMouseListener(ma); for (Component c : getComponents()) c.addMouseListener(ma);
        }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (hov > 0.01f) {
                Graphics2D g2 = (Graphics2D) g.create(); aa(g2); g2.setStroke(new BasicStroke(2.2f));
                g2.setColor(new Color(56, 225, 255, (int) (170 * hov))); g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, r, r); g2.dispose();
            }
        }
    }

    /** Banner principal del catálogo: carrusel automático de sabores con fundido de imágenes. */
    static class Hero extends RP {
        final List<Opcion> list; final Opcion tam; int idx = 0; long last = System.currentTimeMillis();
        final FadeImg im; final JLabel name, desc, price; final Dots dots; final javax.swing.Timer tm;
        Hero(List<Opcion> sabores, Opcion tam, java.util.function.Consumer<Opcion> onAdd) {
            super(CARD, 32); this.list = sabores; this.tam = tam; setLayout(new BorderLayout(26, 0)); setBorder(new EmptyBorder(22, 28, 22, 22));
            JPanel tx = col(); tx.setPreferredSize(new Dimension(380, 300));
            JLabel kick = L("S A B O R   D E S T A C A D O", F(1, 11), GOLD);
            name = new GL(" ", S(1, 46)); desc = L(" ", F(0, 15), MUTED); price = L(" ", S(1, 34), GOLD);
            kick.setAlignmentX(0); name.setAlignmentX(0); desc.setAlignmentX(0); price.setAlignmentX(0);
            Btn btnAdd = new Btn("Agregar al carrito", PINK, false); btnAdd.setAlignmentX(0);
            btnAdd.addActionListener(e -> onAdd.accept(list.get(idx)));
            Btn prev = new Btn("‹", new Color(40, 46, 80), false), next = new Btn("›", new Color(40, 46, 80), false);
            prev.addActionListener(e -> show((idx - 1 + list.size()) % list.size())); next.addActionListener(e -> show((idx + 1) % list.size()));
            dots = new Dots(sabores.size(), this::show);
            JPanel ctl = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); ctl.setOpaque(false); ctl.setAlignmentX(0); ctl.add(prev); ctl.add(dots); ctl.add(next);
            tx.add(Box.createVerticalGlue()); tx.add(kick); tx.add(gap(8)); tx.add(name); tx.add(gap(6)); tx.add(desc); tx.add(gap(14));
            tx.add(price); tx.add(gap(18)); tx.add(btnAdd); tx.add(gap(18)); tx.add(ctl); tx.add(Box.createVerticalGlue());
            im = new FadeImg(imgFor(sabores.get(0).nombre)); im.contain = true; im.setPreferredSize(new Dimension(520, 320));
            add(tx, BorderLayout.CENTER); add(im, BorderLayout.EAST);
            tm = new javax.swing.Timer(120, e -> tick());
            show(0);
        }
        void show(int i) {
            idx = i; last = System.currentTimeMillis(); Opcion o = list.get(i);
            name.setText(o.nombre); desc.setText("<html><div style='width:360px'>" + o.detalle + "</div></html>"); price.setText(money(tam.precio + o.precio));
            im.title = "Cheesecake " + o.nombre; im.sub = "Tamaño " + tam.nombre + " · " + tam.detalle; im.setImage(imgFor(o.nombre));
            dots.cur = i; dots.repaint(); repaint();
        }
        void tick() {
            if (!isShowing() || list.size() < 2) return;
            boolean over = false; try { over = getMousePosition(true) != null; } catch (Exception ex) { }
            if (over) last = System.currentTimeMillis();
            else if (System.currentTimeMillis() - last > 4500) show((idx + 1) % list.size());
        }
        public void addNotify() { super.addNotify(); tm.start(); }
        public void removeNotify() { tm.stop(); super.removeNotify(); }
    }

    // ---------- lógica ----------
    static void addCart(String name, String im, int price, String detail, int idTam, int idSab, List<Integer> tops, List<Integer> exts) {
        for (ItemCarrito i : cart) if (i.name.equals(name) && i.detail.equals(detail)) { i.qty++; refreshNav(); return; }
        cart.add(new ItemCarrito(name, im, price, detail, idTam, idSab, tops, exts)); refreshNav();
    }
    static int subtotal() { int s = 0; for (ItemCarrito i : cart) s += i.price * i.qty; return s; }
    static void refreshNav() {
        int n = 0; for (ItemCarrito i : cart) n += i.qty;
        nav.get("cart").setText("Carrito" + (n > 0 ? " (" + n + ")" : ""));
        nav.get("login").setText(user == null ? "Login" : "Cuenta: " + user.usuario);
    }
    static void go(String n) {
        current = n;
        builders.get(n).run(); cl.show(content, n); for (Map.Entry<String, Btn> e : nav.entrySet()) e.getValue().setActive(e.getKey().equals(n)); refreshNav();
    }
    /** Imagen según el sabor; los sabores sin foto propia usan la imagen genérica. */
    static String imgFor(String n) {
        String k = java.text.Normalizer.normalize(n, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
        if (k.contains("oreo")) return "oreo";
        if (k.contains("frutos")) return "frutos";
        if (k.contains("maracuya")) return "maracuya";
        if (k.contains("limon")) return "limon";
        if (k.contains("arandano")) return "arandanos";
        return "custom";
    }
    static void dbError(JPanel p, Exception e) {
        RP c = card(34); c.add(ctr(L("No se pudo leer la base de datos", S(1, 22), WHITE))); c.add(gap(8));
        String m = String.valueOf(e.getMessage()).replace("&", "&amp;").replace("<", "&lt;");
        c.add(ctr(L("<html><div style='text-align:center;width:460px'>" + m + "</div></html>", F(0, 12), MUTED))); c.add(gap(16));
        Btn b = new Btn("Reintentar", PINK, false); b.addActionListener(ev -> go(current)); c.add(ctr(b));
        p.add(centered(c), BorderLayout.CENTER);
    }
    static Opcion tamanoBase(List<Opcion> t) {
        for (Opcion o : t) if (o.nombre.equalsIgnoreCase("Mediano")) return o;
        return t.isEmpty() ? null : t.get(0);
    }

    // ---------- 1. Catálogo (carrusel animado + tarjetas con efecto; sabores y tamaño mediano leídos de la BD) ----------
    static void catalog(JPanel p) {
        p.add(header("Nuestros Cheesecakes", "Sabores artesanales hechos a mano con ingredientes premium"), BorderLayout.NORTH);
        List<Opcion> sabores, tamanos;
        try { sabores = CatalogoDAO.listar(CatalogoDAO.Tipo.SABORES); tamanos = CatalogoDAO.listar(CatalogoDAO.Tipo.TAMANOS); }
        catch (SQLException e) { dbError(p, e); return; }
        final Opcion tam = tamanoBase(tamanos);
        if (tam == null || sabores.isEmpty()) { empty(p, "El catálogo está vacío", "Reintentar", "catalog"); return; }
        catalogUI(p, sabores, tam);
    }
    static void catalogUI(JPanel p, List<Opcion> sabores, Opcion tam) {
        java.util.function.Consumer<Opcion> agregar = s -> {
            addCart("Cheesecake " + s.nombre, imgFor(s.nombre), tam.precio + s.precio, "Tamaño " + tam.nombre + " (" + tam.detalle + "), receta clásica",
                    tam.id, s.id, new ArrayList<>(), new ArrayList<>());
            int r = JOptionPane.showOptionDialog(frame, "Cheesecake " + s.nombre + " agregado al carrito", "Romale Desserts", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE, img("logo", 48, 48), new String[]{"Seguir viendo", "Ir al carrito"}, "Ir al carrito");
            if (r == 1) go("cart");
        };
        JPanel body = col(); body.setBorder(new EmptyBorder(8, 30, 30, 30));
        Hero hero = new Hero(sabores, tam, agregar); hero.setAlignmentX(0); body.add(hero); body.add(gap(28));
        JLabel t = L("Todos los sabores", S(1, 22), WHITE); t.setAlignmentX(0); body.add(t); body.add(gap(14));
        JPanel g = new JPanel(new GridLayout(0, Math.min(5, sabores.size()), 16, 16)); g.setOpaque(false); g.setAlignmentX(0);
        for (Opcion s : sabores) g.add(new ProdCard(s, tam.precio + s.precio, () -> agregar.accept(s)));
        body.add(g);
        JPanel w = new JPanel(new BorderLayout()); w.setOpaque(false); w.add(body, BorderLayout.NORTH); p.add(sp(w), BorderLayout.CENTER);
    }

    // ---------- 2. Personalizar (vista previa animada, chips y precio que cambia en vivo) ----------
    static void custom(JPanel p) {
        p.add(header("Personaliza tu Cheesecake", "Elige tamaño, sabor, extras y toppings: tú lo diseñas"), BorderLayout.NORTH);
        List<Opcion> tams, sabs, tops, exts;
        try { tams = CatalogoDAO.listar(CatalogoDAO.Tipo.TAMANOS); sabs = CatalogoDAO.listar(CatalogoDAO.Tipo.SABORES);
              tops = CatalogoDAO.listar(CatalogoDAO.Tipo.TOPPINGS); exts = CatalogoDAO.listar(CatalogoDAO.Tipo.EXTRAS); }
        catch (SQLException e) { dbError(p, e); return; }
        if (tams.isEmpty() || sabs.isEmpty()) { empty(p, "El catálogo está vacío", "Reintentar", "custom"); return; }
        customUI(p, tams, sabs, tops, exts);
    }
    static int sel(Chip[] c) { for (int i = 0; i < c.length; i++) if (c[i].isSelected()) return i; return 0; }
    static JPanel grid(int cols) { JPanel g = new JPanel(new GridLayout(0, cols, 8, 8)); g.setOpaque(false); g.setAlignmentX(0); return g; }
    static JLabel sec(String t) { JLabel l = L(t, S(1, 18), PINK); l.setAlignmentX(0); l.setBorder(new EmptyBorder(14, 0, 8, 0)); return l; }

    static void customUI(JPanel p, List<Opcion> T, List<Opcion> S_, List<Opcion> TP, List<Opcion> EX) {
        Chip[] flc = new Chip[S_.size()], szc = new Chip[T.size()], tc = new Chip[TP.size()], ec = new Chip[EX.size()];
        ButtonGroup gf = new ButtonGroup(), gs = new ButtonGroup();
        JPanel gFl = grid(2), gSz = grid(3), gEx = grid(3), gTp = grid(3);
        for (int i = 0; i < flc.length; i++) { Opcion o = S_.get(i); flc[i] = new Chip(o.nombre, "+" + money(o.precio), imgFor(o.nombre), false); gf.add(flc[i]); gFl.add(flc[i]); }
        for (int i = 0; i < szc.length; i++) { Opcion o = T.get(i); szc[i] = new Chip(o.nombre, o.detalle + " · " + money(o.precio), null, false); gs.add(szc[i]); gSz.add(szc[i]); }
        for (int i = 0; i < ec.length; i++) { Opcion o = EX.get(i); ec[i] = new Chip(o.nombre, "+" + money(o.precio), null, true); gEx.add(ec[i]); }
        for (int i = 0; i < tc.length; i++) { Opcion o = TP.get(i); tc[i] = new Chip(o.nombre, "+" + money(o.precio), null, true); gTp.add(tc[i]); }
        flc[0].setSelected(true); szc[Math.max(0, T.indexOf(tamanoBase(T)))].setSelected(true);

        FadeImg pv = new FadeImg(imgFor(S_.get(0).nombre)); pv.contain = true; pv.setPreferredSize(new Dimension(480, 380)); pv.setMaximumSize(new Dimension(Integer.MAX_VALUE, 380)); pv.setAlignmentX(0.5f);
        JLabel tot = L("", S(1, 40), GOLD); NumAnim anim = new NumAnim(tot, 0);
        Runnable[] up = new Runnable[1];
        up[0] = () -> {
            Opcion s = S_.get(sel(flc)), t = T.get(sel(szc)); int v = t.precio + s.precio, ne = 0, nt = 0;
            for (int i = 0; i < ec.length; i++) if (ec[i].isSelected()) { v += EX.get(i).precio; ne++; }
            for (int i = 0; i < tc.length; i++) if (tc[i].isSelected()) { v += TP.get(i).precio; nt++; }
            pv.setImage(imgFor(s.nombre)); pv.title = "Cheesecake " + s.nombre;
            pv.sub = "Tamaño " + t.nombre + " · " + t.detalle + (ne > 0 ? " · " + ne + (ne == 1 ? " extra" : " extras") : "") + (nt > 0 ? " · " + nt + (nt == 1 ? " topping" : " toppings") : "");
            pv.repaint(); anim.set(v);
        };
        java.awt.event.ActionListener al = e -> up[0].run();
        for (Chip[] arr : new Chip[][]{flc, szc, ec, tc}) for (Chip c : arr) c.addActionListener(al);

        RP left = card(18); left.add(pv); left.add(gap(14));
        JPanel bot = new JPanel(new BorderLayout()); bot.setOpaque(false); bot.setAlignmentX(0.5f);
        JPanel lt = col(); JLabel cap = L("T U   T O T A L", F(1, 11), MUTED); cap.setAlignmentX(0); tot.setAlignmentX(0); lt.add(cap); lt.add(tot);
        Btn add = new Btn("Agregar al carrito", PINK, false); JPanel bw = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 12)); bw.setOpaque(false); bw.add(add);
        bot.add(lt, BorderLayout.WEST); bot.add(bw, BorderLayout.EAST); left.add(bot);
        RP right = card(22);
        right.add(sec("1. Elige tu sabor")); right.add(gFl);
        right.add(sec("2. Tamaño")); right.add(gSz);
        right.add(sec("3. Extras")); right.add(gEx);
        right.add(sec("4. Toppings")); right.add(gTp);
        add.addActionListener(e -> {
            Opcion s = S_.get(sel(flc)), t = T.get(sel(szc));
            int v = t.precio + s.precio; StringBuilder d = new StringBuilder("Tamaño " + t.nombre + " (" + t.detalle + "), sabor " + s.nombre);
            List<Integer> tIds = new ArrayList<>(), eIds = new ArrayList<>(); List<String> tN = new ArrayList<>(), eN = new ArrayList<>();
            for (int i = 0; i < ec.length; i++) if (ec[i].isSelected()) { v += EX.get(i).precio; eIds.add(EX.get(i).id); eN.add(EX.get(i).nombre); }
            for (int i = 0; i < tc.length; i++) if (tc[i].isSelected()) { v += TP.get(i).precio; tIds.add(TP.get(i).id); tN.add(TP.get(i).nombre); }
            if (!eN.isEmpty()) d.append(", extras: ").append(String.join(", ", eN));
            if (!tN.isEmpty()) d.append(", toppings: ").append(String.join(", ", tN));
            addCart("Cheesecake personalizado (" + s.nombre + ")", imgFor(s.nombre), v, d.toString(), t.id, s.id, tIds, eIds);
            go("cart");
        });
        up[0].run(); anim.jump();
        JPanel lw = new JPanel(new BorderLayout()); lw.setOpaque(false); lw.add(left, BorderLayout.NORTH);
        JPanel body = new JPanel(new BorderLayout(22, 0)); body.setOpaque(false); body.setBorder(new EmptyBorder(6, 30, 24, 30));
        body.add(lw, BorderLayout.WEST); body.add(right, BorderLayout.CENTER); p.add(sp(body), BorderLayout.CENTER);
    }

    // ---------- 3. Carrito ----------
    static void cartView(JPanel p) {
        p.add(header("Tu Carrito", "Revisa tus cheesecakes antes de pagar"), BorderLayout.NORTH);
        if (cart.isEmpty()) { empty(p, "Tu carrito está vacío", "Ver catálogo", "catalog"); return; }
        JPanel rows = col(); rows.setBorder(new EmptyBorder(6, 30, 20, 12));
        for (ItemCarrito it : new ArrayList<>(cart)) {
            RP r = new RP(CARD, 24); r.setLayout(new BorderLayout(14, 0)); r.setBorder(new EmptyBorder(10, 12, 10, 16)); r.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
            r.add(new JLabel(img(it.img, 96, 76)), BorderLayout.WEST);
            JPanel mid = col(); mid.add(L(it.name, F(1, 15), WHITE)); mid.add(L("<html><div style='width:330px'>" + it.detail + "</div></html>", F(0, 11), MUTED));
            JPanel east = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 20)); east.setOpaque(false);
            Btn m = new Btn("-", new Color(60, 60, 70), false), pl = new Btn("+", new Color(60, 60, 70), false), x = new Btn("x", new Color(150, 50, 70), false);
            for (Btn b : new Btn[]{m, pl, x}) { b.setForeground(WHITE); b.setBorder(new EmptyBorder(4, 10, 4, 10)); }
            m.addActionListener(e -> { if (--it.qty <= 0) cart.remove(it); go("cart"); }); pl.addActionListener(e -> { it.qty++; go("cart"); }); x.addActionListener(e -> { cart.remove(it); go("cart"); });
            east.add(m); east.add(L("" + it.qty, F(1, 15), WHITE)); east.add(pl); east.add(L(money(it.price * it.qty), S(1, 20), GOLD)); east.add(x);
            r.add(mid, BorderLayout.CENTER); r.add(east, BorderLayout.EAST); rows.add(r); rows.add(gap(10));
        }
        p.add(sp(rows), BorderLayout.CENTER);
        RP side = card(24);
        side.add(ctr(L("Resumen", S(1, 24), GOLD))); side.add(gap(18));
        side.add(line("Subtotal", money(subtotal()), WHITE)); side.add(line("Envío", money(ENVIO), WHITE)); side.add(gap(8)); side.add(line("Total", money(subtotal() + ENVIO), GOLD)); side.add(gap(22));
        Btn pay = ctr(new Btn("Proceder al pago", PINK, false)), more = ctr(new Btn("Seguir comprando", new Color(60, 60, 70), false)); more.setForeground(WHITE);
        pay.addActionListener(e -> go("payment")); more.addActionListener(e -> go("catalog")); side.add(pay); side.add(gap(10)); side.add(more);
        JPanel w = new JPanel(new BorderLayout()); w.setOpaque(false); w.setBorder(new EmptyBorder(6, 0, 24, 30)); w.setPreferredSize(new Dimension(340, 10)); w.add(side, BorderLayout.NORTH); p.add(w, BorderLayout.EAST);
    }
    static JPanel line(String a, String b, Color c) { JPanel l = new JPanel(new BorderLayout()); l.setOpaque(false); l.setMaximumSize(new Dimension(999, 30));
        l.add(L(a, F(0, 15), MUTED), BorderLayout.WEST); l.add(L(b, F(1, 17), c), BorderLayout.EAST); return l; }

    // ---------- 4. Login (consulta clientes_internos y clientes) ----------
    static void login(JPanel p) {
        p.add(header("Iniciar sesión", "Accede a tu cuenta Romale"), BorderLayout.NORTH);
        RP c = card(32); c.setPreferredSize(new Dimension(440, 520));
        c.add(ctr(new JLabel(img("logo", 110, 110)))); c.add(gap(6));
        if (user != null) {
            c.add(ctr(L("¡Hola, " + user.nombre + "!", S(1, 24), GOLD))); c.add(gap(8));
            c.add(ctr(L(user.isAdmin() ? "Sesión activa · Administrador" : "Tu sesión está activa", F(0, 14), MUTED))); c.add(gap(24));
            Btn out = ctr(new Btn("Cerrar sesión", PINK, false)); out.addActionListener(e -> { user = null; go("login"); }); c.add(out);
        } else {
            c.add(ctr(L("Bienvenida a Romale", S(1, 22), WHITE))); c.add(gap(14));
            JTextField u = field(c, "Usuario", false), pw = field(c, "Contraseña", true); c.add(gap(6));
            Btn in = ctr(new Btn("Ingresar", PINK, false)); Btn reg = ctr(new Btn("¿Nuevo aquí? Crea tu cuenta", GOLD, true)); reg.setForeground(GOLD);
            Runnable doIt = () -> {
                String us = u.getText().trim(), pwd = new String(((JPasswordField) pw).getPassword());
                if (us.isEmpty() || pwd.isEmpty()) { say("Ingresa tu usuario y contraseña."); return; }
                try {
                    Usuario x = UsuarioDAO.autenticar(us, pwd);
                    if (x == null) { say("Usuario o contraseña incorrectos."); return; }
                    user = x; go(user.isAdmin() ? "admin" : "catalog");
                } catch (SQLException ex) { say("No se pudo iniciar sesión:\n" + ex.getMessage()); }
            };
            in.addActionListener(e -> doIt.run()); pw.addActionListener(e -> doIt.run()); reg.addActionListener(e -> go("register"));
            c.add(in); c.add(gap(8)); c.add(reg);
        }
        p.add(centered(c), BorderLayout.CENTER);
    }

    // ---------- 5. Registro (guarda en clientes o, si es administrador, en clientes_internos) ----------
    static void register(JPanel p) {
        p.add(header("Crear cuenta", "Únete a la dulce experiencia Romale Desserts"), BorderLayout.NORTH);
        RP c = card(30);
        JPanel cols = new JPanel(new GridLayout(1, 2, 24, 0)); cols.setOpaque(false);
        JPanel c1 = col(), c2 = col();
        JTextField n = field(c1, "Nombre completo", false), m = field(c1, "Correo electrónico", false), u = field(c1, "Usuario", false),
                t = field(c1, "Teléfono (opcional)", false), d = field(c1, "Dirección de entrega", false);
        JTextField a = field(c2, "Contraseña (mín. 4 caracteres)", true), b = field(c2, "Confirmar contraseña", true);
        c2.add(ctr(L("Tipo de cuenta", F(0, 12), MUTED))); c2.add(gap(3));
        JComboBox<String> tipo = new JComboBox<>(new String[]{"Cliente", "Administrador"}); combo(tipo);
        tipo.setPreferredSize(new Dimension(340, 42)); tipo.setMaximumSize(new Dimension(340, 42)); tipo.setAlignmentX(0.5f); c2.add(tipo); c2.add(gap(10));
        JPanel box = col(); box.setVisible(false); JTextField code = field(box, "Código de administrador", true); c2.add(box);
        tipo.addActionListener(e -> box.setVisible(tipo.getSelectedIndex() == 1));
        cols.add(c1); cols.add(c2); c.add(cols); c.add(gap(10));
        Btn ok = ctr(new Btn("Crear mi cuenta", PINK, false)); Btn back = ctr(new Btn("Ya tengo cuenta", GOLD, true)); back.setForeground(GOLD);
        ok.addActionListener(e -> {
            String nm = n.getText().trim(), mail = m.getText().trim(), us = u.getText().trim(), tel = t.getText().trim(), dir = d.getText().trim(),
                    p1 = new String(((JPasswordField) a).getPassword()), p2 = new String(((JPasswordField) b).getPassword());
            boolean adm = tipo.getSelectedIndex() == 1;
            if (nm.isEmpty() || us.isEmpty() || p1.isEmpty()) { say("Completa todos los campos."); return; }
            if (!mail.matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) { say("Ingresa un correo válido."); return; }
            if (!tel.isEmpty() && !tel.matches("\\d{7,15}")) { say("El teléfono debe tener solo números (7 a 15 dígitos)."); return; }
            if (!adm && dir.isEmpty()) { say("Escribe tu dirección de entrega."); return; }
            if (p1.length() < 4) { say("La contraseña debe tener al menos 4 caracteres."); return; }
            if (!p1.equals(p2)) { say("Las contraseñas no coinciden."); return; }
            try {
                String err = adm ? UsuarioDAO.registrarAdministrador(nm, mail, us, p1, tel, new String(((JPasswordField) code).getPassword()))
                                 : UsuarioDAO.registrarCliente(nm, mail, us, p1, tel, dir);
                if (err != null) { say(err); return; }
                say("¡Cuenta creada! Ahora inicia sesión."); go("login");
            } catch (SQLException ex) { say("No se pudo guardar tu cuenta:\n" + ex.getMessage()); }
        });
        back.addActionListener(e -> go("login")); c.add(ok); c.add(gap(8)); c.add(back); p.add(sp(centered(c)), BorderLayout.CENTER);
    }

    // ---------- facturas (PDF + correo) ----------
    static void abrirArchivo(File f) {
        try { if (Desktop.isDesktopSupported()) { Desktop.getDesktop().open(f); return; } } catch (Exception e) { }
        say("Tu factura quedó guardada en:\n" + f.getAbsolutePath());
    }
    /**
     * Trabajo de factura en segundo plano (no congela la pantalla).
     * modo "compra" = acaba de comprar: guarda el PDF y lo envía al correo del cliente.
     * modo "enviar" = reenvía el PDF por correo.  modo "ver" = solo abre el PDF.
     */
    static void trabajoFactura(String codigo, String modo) {
        new SwingWorker<Object[], Void>() {
            protected Object[] doInBackground() throws Exception {
                Factura f = FacturaDAO.cargarPorCodigo(codigo); File pdf = FacturaServicio.guardarPdf(f); String err = null;
                if (!modo.equals("ver")) {
                    if (!Correo.configurado()) err = "NOCONFIG";
                    else { try { FacturaServicio.enviarCorreo(f); } catch (Exception ex) { err = String.valueOf(ex.getMessage()); } }
                }
                return new Object[]{f, pdf, err};
            }
            protected void done() {
                try {
                    Object[] r = get(); Factura f = (Factura) r[0]; File pdf = (File) r[1]; String err = (String) r[2];
                    if (modo.equals("ver")) { abrirArchivo(pdf); return; }
                    String msg;
                    if (err == null) msg = "Enviamos la factura " + f.numero + " a\n" + f.correo;
                    else if (err.equals("NOCONFIG")) msg = "Tu factura " + f.numero + " está lista.\n\n(El envío por correo todavía no está configurado:\nllena USUARIO y CLAVE en servicios/Correo.java)";
                    else msg = "No pudimos enviar el correo a " + f.correo + ":\n" + err + "\n\nTu factura " + f.numero + " quedó guardada.";
                    int o = JOptionPane.showOptionDialog(frame, msg, "Factura " + f.numero, JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                            img("logo", 48, 48), new String[]{"Ver factura", "Cerrar"}, "Ver factura");
                    if (o == 0) abrirArchivo(pdf);
                } catch (Exception ex) {
                    Throwable c = ex.getCause() != null ? ex.getCause() : ex;
                    say("No se pudo generar la factura:\n" + c.getMessage());
                }
            }
        }.execute();
    }
    static Btn botonFactura(String texto, String codigo, String modo) {
        Btn b = new Btn(texto, new Color(60, 66, 110), false); b.setFont(F(1, 12)); b.setBorder(new EmptyBorder(7, 16, 7, 16)); b.setAlignmentX(1f);
        b.addActionListener(e -> trabajoFactura(codigo, modo)); return b;
    }

    // ---------- 6. Mis pedidos (BD): estado, repartidor y reembolsos ----------
    static String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }
    static <T extends JComponent> T left(T c) { c.setAlignmentX(0); return c; }
    static boolean confirmar(String msg, String si) {
        return JOptionPane.showOptionDialog(frame, msg, "Romale Desserts", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                img("logo", 48, 48), new String[]{si, "Cancelar"}, "Cancelar") == 0;
    }
    static Color colorEstado(String e) {
        if (e == null) return MUTED;
        switch (e) {
            case "Entregado": case "Aprobada": return new Color(110, 210, 140);
            case "Cancelado": case "Rechazada": return new Color(225, 95, 95);
            case "Reembolsado": return VIOLET;
            case "En camino": return GOLD;
            case "En revisión": return new Color(255, 190, 80);
            default: return PINK;
        }
    }

    /** Etiqueta redondeada de estado. */
    static class Pill extends JLabel {
        final Color c;
        Pill(String t, Color c) { super(t); this.c = c; setFont(F(1, 11)); setForeground(c); setBorder(new EmptyBorder(3, 11, 3, 11)); setOpaque(false); setAlignmentX(0); }
        public Dimension getMaximumSize() { return getPreferredSize(); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); int w = getWidth() - 1, h = getHeight() - 1;
            g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 38)); g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(new Color(c.getRed(), c.getGreen(), c.getBlue(), 150)); g2.drawRoundRect(0, 0, w, h, h, h); g2.dispose(); super.paintComponent(g);
        }
    }

    /** Línea de progreso del pedido: Recibido -> En preparación -> En camino -> Entregado. */
    static class Steps extends JComponent {
        static final String[] N = {"Recibido", "En preparación", "En camino", "Entregado"}; final int cur;
        Steps(int cur) { this.cur = cur; setAlignmentX(0); }
        public Dimension getPreferredSize() { return new Dimension(460, 44); }
        public Dimension getMaximumSize() { return getPreferredSize(); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); aa(g2); int pad = 50, span = getWidth() - 2 * pad;
            g2.setStroke(new BasicStroke(2f));
            for (int i = 0; i < 3; i++) { g2.setColor(i < cur ? PINK : EDGE); g2.drawLine(pad + i * span / 3 + 8, 10, pad + (i + 1) * span / 3 - 8, 10); }
            for (int i = 0; i < 4; i++) {
                int x = pad + i * span / 3; boolean on = i <= cur;
                if (i == cur) { g2.setColor(new Color(56, 225, 255, 70)); g2.fillOval(x - 10, 0, 20, 20); }
                g2.setColor(on ? (i == cur ? GOLD : PINK) : EDGE); g2.fillOval(x - 6, 4, 12, 12);
                g2.setFont(F(i == cur ? 1 : 0, 10)); g2.setColor(on ? WHITE : MUTED); FontMetrics fm = g2.getFontMetrics();
                g2.drawString(N[i], x - fm.stringWidth(N[i]) / 2, 34);
            }
            g2.dispose();
        }
    }

    /** Ventana para pedir el motivo del reembolso. Devuelve null si el cliente cancela. */
    static String pedirMotivo(PedidoResumen o) {
        String[] mot = {"Producto dañado o aplastado", "Sabor o producto diferente al pedido", "Faltaron extras o toppings",
                "Entrega tardía", "Quiero cancelar el pedido", "No coincide con la foto", "Otro motivo"};
        JPanel pn = col();
        pn.add(left(L("Reembolso del pedido " + o.codigo + "  ·  " + money(o.total), S(1, 16), WHITE))); pn.add(gap(12));
        pn.add(left(L("¿Cuál es el motivo?", F(0, 12), MUTED))); pn.add(gap(4));
        JComboBox<String> cb = new JComboBox<>(mot); combo(cb); cb.setAlignmentX(0); cb.setMaximumSize(new Dimension(440, 36)); cb.setPreferredSize(new Dimension(440, 36)); pn.add(cb); pn.add(gap(12));
        pn.add(left(L("Cuéntanos más (opcional)", F(0, 12), MUTED))); pn.add(gap(4));
        JTextArea ta = new JTextArea(4, 36); ta.setBackground(FIELD); ta.setForeground(WHITE); ta.setCaretColor(GOLD); ta.setLineWrap(true); ta.setWrapStyleWord(true);
        ta.setFont(F(0, 13)); ta.setBorder(new EmptyBorder(8, 10, 8, 10));
        JScrollPane sc = new JScrollPane(ta); sc.setBorder(new LineBorder(EDGE, 1, true)); sc.setAlignmentX(0); sc.setMaximumSize(new Dimension(440, 110)); pn.add(sc); pn.add(gap(10));
        pn.add(left(L("<html><div style='width:420px'>Atención al cliente revisará tu solicitud y verás la respuesta en Mis pedidos.</div></html>", F(0, 11), MUTED)));
        while (true) {
            int r = JOptionPane.showOptionDialog(frame, pn, "Solicitar reembolso", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                    img("logo", 48, 48), new String[]{"Enviar solicitud", "Cancelar"}, "Enviar solicitud");
            if (r != 0) return null;
            String d = ta.getText().trim(), m = (String) cb.getSelectedItem();
            if (cb.getSelectedIndex() == mot.length - 1 && d.isEmpty()) { say("Cuéntanos el motivo en el cuadro de texto."); continue; }
            return d.isEmpty() ? m : m + ": " + d;
        }
    }
    static JComponent botonReembolso(PedidoResumen o, String texto) {
        Btn b = new Btn(texto, new Color(60, 66, 110), false); b.setFont(F(1, 12)); b.setBorder(new EmptyBorder(8, 18, 8, 18));
        b.addActionListener(e -> {
            String motivo = pedirMotivo(o); if (motivo == null) return;
            try {
                ReembolsoDAO.solicitar(o.idPedido, motivo);
                say("Solicitud enviada.\nAtención al cliente revisará el reembolso del pedido " + o.codigo + " y verás la respuesta aquí.");
                go("orders");
            } catch (SQLException ex) { say("No se pudo enviar la solicitud:\n" + ex.getMessage()); }
        });
        JPanel w = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0)); w.setOpaque(false); w.add(b); return w;
    }
    static JComponent refundPanel(PedidoResumen o) {
        JPanel p = new JPanel(new BorderLayout(14, 0)); p.setOpaque(false);
        p.setBorder(new CompoundBorder(new MatteBorder(1, 0, 0, 0, new Color(40, 48, 85)), new EmptyBorder(12, 0, 0, 0)));
        if (o.idDevolucion == 0) {
            p.add(L("<html><div style='width:560px'>¿Hubo algún problema con tu pedido? Puedes solicitar un reembolso y te responderemos aquí mismo.</div></html>", F(0, 12), MUTED), BorderLayout.CENTER);
            p.add(botonReembolso(o, "Solicitar reembolso"), BorderLayout.EAST);
        } else {
            boolean ok = ReembolsoDAO.APROBADA.equals(o.devEstado), no = ReembolsoDAO.RECHAZADA.equals(o.devEstado);
            String quien = esc(o.devAtendio == null ? "Atención al cliente" : o.devAtendio);
            JPanel i = col(); i.add(new Pill("Reembolso " + o.devEstado.toLowerCase(), colorEstado(o.devEstado))); i.add(gap(6));
            i.add(left(L("<html><div style='width:620px'>Motivo: " + esc(o.devMotivo) + "  ·  Solicitado el " + esc(o.devFecha) + "</div></html>", F(0, 12), MUTED)));
            i.add(gap(2));
            if (ok) i.add(left(L("<html>Monto reembolsado: <b>" + money(o.devMonto) + "</b>  ·  Aprobado por " + quien + "</html>", F(0, 12), colorEstado("Aprobada"))));
            else if (no) i.add(left(L("<html>Rechazado por " + quien + ". Puedes volver a solicitarlo si lo necesitas.</html>", F(0, 12), colorEstado("Rechazada"))));
            else i.add(left(L("<html>Lo está revisando <b>" + quien + "</b> (Atención al cliente). Aquí verás la respuesta.</html>", F(0, 12), colorEstado("En revisión"))));
            p.add(i, BorderLayout.CENTER);
            if (no) p.add(botonReembolso(o, "Volver a solicitar"), BorderLayout.EAST);
        }
        return p;
    }
    static JComponent orderCard(PedidoResumen o) {
        RP r = new RP(CARD, 24); r.setLayout(new BorderLayout(20, 8)); r.setBorder(new EmptyBorder(16, 22, 14, 22));
        JPanel l = new JPanel() { public Dimension getPreferredSize() { Dimension d = super.getPreferredSize(); return new Dimension(Math.max(d.width, 120), d.height); } };
        l.setLayout(new BoxLayout(l, BoxLayout.Y_AXIS)); l.setOpaque(false);
        l.add(left(L(o.codigo, S(1, 20), GOLD))); l.add(left(L(o.fecha, F(0, 12), MUTED))); l.add(gap(8)); l.add(new Pill(o.estado, colorEstado(o.estado)));
        JPanel c = col();
        c.add(left(L("<html><div style='width:460px'>" + esc(o.detalle) + "</div></html>", F(0, 14), WHITE))); c.add(gap(8));
        String rep = o.repartidor == null ? "<span style='color:#FFBE50'>Por asignar</span>"
                : "<b>" + esc(o.repartidor) + "</b>" + (o.repartidorTel == null ? "" : "  ·  " + esc(o.repartidorTel));
        c.add(left(L("<html><span style='color:#8B94B0'>Repartidor:</span>  " + rep + "</html>", F(0, 13), WHITE)));
        if (o.direccion != null && !o.direccion.isEmpty())
            c.add(left(L("<html><span style='color:#8B94B0'>Entrega en:</span>  " + esc(o.direccion) + "</html>", F(0, 13), WHITE)));
        int paso = Arrays.asList(Steps.N).indexOf(o.estado);
        if (paso >= 0) { c.add(gap(6)); c.add(new Steps(paso)); }
        JPanel rt = col(); JLabel t = L(money(o.total), S(1, 22), WHITE); t.setAlignmentX(1f); rt.add(t);
        if (!"Cancelado".equals(o.estado)) { rt.add(gap(10)); rt.add(botonFactura("Ver factura", o.codigo, "ver")); rt.add(gap(6)); rt.add(botonFactura("Enviar al correo", o.codigo, "enviar")); }
        r.add(l, BorderLayout.WEST); r.add(c, BorderLayout.CENTER); r.add(rt, BorderLayout.EAST); r.add(refundPanel(o), BorderLayout.SOUTH);
        return r;
    }
    static void ordersView(JPanel p) {
        p.add(header("Mis Pedidos", "Estado, repartidor y reembolsos de tus compras"), BorderLayout.NORTH);
        if (user == null) { empty(p, "Inicia sesión para ver tus pedidos", "Ir a Login", "login"); return; }
        List<PedidoResumen> lista;
        try { int id = UsuarioDAO.idCliente(user); lista = id < 0 ? new ArrayList<>() : PedidoDAO.listar(id); }
        catch (SQLException e) { dbError(p, e); return; }
        if (lista.isEmpty()) { empty(p, "Aún no tienes pedidos", "Ver catálogo", "catalog"); return; }
        int comprado = 0, aprobado = 0, revision = 0;
        for (PedidoResumen o : lista) {
            if (!"Cancelado".equals(o.estado) && !"Reembolsado".equals(o.estado)) comprado += o.total;
            if (ReembolsoDAO.APROBADA.equals(o.devEstado)) aprobado += o.devMonto;
            if (ReembolsoDAO.EN_REVISION.equals(o.devEstado)) revision++;
        }
        JPanel rows = col(); rows.setBorder(new EmptyBorder(6, 30, 20, 30));
        JPanel stats = left(new JPanel(new GridLayout(1, 4, 14, 0))); stats.setOpaque(false);
        String[][] s = {{"Pedidos", "" + lista.size()}, {"Total comprado", money(comprado)}, {"Reembolsado", money(aprobado)}, {"Reembolsos en revisión", "" + revision}};
        for (String[] x : s) { RP c = card(14); c.add(ctr(L(x[0], F(0, 12), MUTED))); c.add(ctr(L(x[1], S(1, 24), GOLD))); stats.add(c); }
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE, stats.getPreferredSize().height)); rows.add(stats); rows.add(gap(12));
        RP info = card(16); info.setAlignmentX(0);
        info.add(left(L("Política de reembolsos", S(1, 16), PINK))); info.add(gap(4));
        info.add(left(L("<html><div style='width:900px'>Puedes solicitar el reembolso de cualquier pedido: producto dañado, diferente al pedido, entrega tardía o cancelación. "
                + "Atención al cliente revisa cada solicitud; si se aprueba verás aquí el monto reembolsado y quién la atendió. "
                + "Si se reembolsa el pedido completo, pasa a estado «Reembolsado».</div></html>", F(0, 12), MUTED)));
        info.setMaximumSize(new Dimension(Integer.MAX_VALUE, info.getPreferredSize().height)); rows.add(info); rows.add(gap(14));
        for (PedidoResumen o : lista) {
            JComponent oc = left(orderCard(o)); oc.setMaximumSize(new Dimension(Integer.MAX_VALUE, oc.getPreferredSize().height)); rows.add(oc); rows.add(gap(12));
        }
        p.add(sp(rows), BorderLayout.CENTER);
    }

    // ---------- 7. Pago (guarda el pedido en la BD) ----------
    static void payment(JPanel p) {
        p.add(header("Pago", "Elige tu medio de pago (simulado)"), BorderLayout.NORTH);
        if (cart.isEmpty()) { empty(p, "No hay productos para pagar", "Ver catálogo", "catalog"); return; }
        String[] meth = {"Tarjeta crédito / débito", "Nequi", "Daviplata", "PSE - Transferencia bancaria", "Efectivo contra entrega"};
        RP left = card(24); left.add(L("Medio de pago", S(1, 22), GOLD)); left.add(gap(8));
        ButtonGroup g = new ButtonGroup(); JRadioButton[] rb = new JRadioButton[5];
        JPanel cf = col(), ph = col(); cf.setAlignmentX(0); ph.setAlignmentX(0);
        JTextField num = field(cf, "Número de tarjeta", false), nom = field(cf, "Nombre del titular", false), exp = field(cf, "Vencimiento (MM/AA)", false), cvv = field(cf, "CVV", true),
                cel = field(ph, "Número de celular", false); ph.setVisible(false);
        for (int i = 0; i < 5; i++) { final int k = i; rb[i] = sty(new JRadioButton(meth[i])); rb[i].setFont(F(1, 15)); g.add(rb[i]); left.add(rb[i]);
            rb[i].addActionListener(e -> { cf.setVisible(k == 0); ph.setVisible(k == 1 || k == 2); }); }
        rb[0].setSelected(true); left.add(gap(10)); left.add(cf); left.add(ph);
        JTextField dir = field(left, "Dirección de entrega", false); if (user != null && user.direccion != null) dir.setText(user.direccion);
        RP right = card(24); right.add(ctr(L("Resumen del pedido", S(1, 22), GOLD))); right.add(gap(12));
        for (ItemCarrito it : cart) right.add(line(it.qty + "x " + it.name.replace("Cheesecake ", ""), money(it.price * it.qty), WHITE));
        right.add(gap(8)); right.add(line("Envío", money(ENVIO), MUTED)); right.add(line("Total", money(subtotal() + ENVIO), GOLD)); right.add(gap(20));
        Btn ok = ctr(new Btn("Confirmar pago", PINK, false)); right.add(ok);
        ok.addActionListener(e -> {
            if (user == null) { say("Inicia sesión para completar tu compra."); go("login"); return; }
            int idx = 0; for (int i = 0; i < 5; i++) if (rb[i].isSelected()) idx = i;
            if (idx == 0 && (num.getText().replaceAll("\\s", "").length() != 16 || nom.getText().trim().isEmpty() || !exp.getText().matches("\\d\\d/\\d\\d") || new String(((JPasswordField) cvv).getPassword()).length() != 3)) { say("Revisa los datos de la tarjeta (16 dígitos, vencimiento MM/AA, CVV de 3 dígitos)."); return; }
            if ((idx == 1 || idx == 2) && !cel.getText().matches("\\d{10}")) { say("Ingresa un celular de 10 dígitos."); return; }
            if (dir.getText().trim().isEmpty()) { say("Escribe la dirección de entrega."); return; }
            try {
                String codigo = PedidoDAO.crearPedido(user, cart, dir.getText().trim(), ENVIO);
                cart.clear(); say("¡Pago exitoso (simulado)!\nPedido " + codigo + " · " + meth[idx] + "\nEstamos generando tu factura..."); go("orders"); trabajoFactura(codigo, "compra");
            } catch (SQLException ex) { say("No se pudo registrar el pedido:\n" + ex.getMessage()); }
        });
        JPanel body = new JPanel(new GridLayout(1, 2, 22, 0)); body.setOpaque(false); body.setBorder(new EmptyBorder(6, 30, 24, 30)); body.add(left);
        JPanel w = new JPanel(new BorderLayout()); w.setOpaque(false); w.add(right, BorderLayout.NORTH); body.add(w); p.add(sp(body), BorderLayout.CENTER);
    }

    // ---------- 8. Panel administrativo (datos de la BD): precios, pedidos, repartidores y reembolsos ----------
    static Btn adminBtn(String t, Color c) { Btn b = new Btn(t, c, false); b.setFont(F(1, 12)); b.setBorder(new EmptyBorder(8, 16, 8, 16)); return b; }
    static void admin(JPanel p) {
        p.add(header("Panel Administrativo", "Control y gestión de Romale Desserts"), BorderLayout.NORTH);
        if (user == null || !user.isAdmin()) { empty(p, "Acceso restringido: ingresa como administrador", "Ir a Login", "login"); return; }
        try { PedidoDAO.contarPedidos(); } catch (SQLException e) { dbError(p, e); return; }
        final Color ROJO = new Color(190, 60, 85);
        final List<PedidoResumen> peds = new ArrayList<>(); final List<Reembolso> refs = new ArrayList<>();

        JLabel[] sv = new JLabel[5]; String[] sn = {"Pedidos", "Ventas", "Clientes", "Sabores", "Reembolsos pendientes"};
        JPanel stats = left(new JPanel(new GridLayout(1, 5, 16, 0))); stats.setOpaque(false);
        for (int i = 0; i < 5; i++) { RP c = card(16); sv[i] = L("…", S(1, 26), GOLD); c.add(ctr(L(sn[i], F(0, 13), MUTED))); c.add(ctr(sv[i])); stats.add(c); }

        // ---- catálogo y precios
        CatalogoDAO.Tipo[] tipos = CatalogoDAO.Tipo.values();
        String[] tn = new String[tipos.length]; for (int i = 0; i < tn.length; i++) tn[i] = tipos[i].titulo;
        JComboBox<String> tsel = new JComboBox<>(tn); combo(tsel); tsel.setMaximumSize(new Dimension(300, 32)); tsel.setAlignmentX(0);
        DefaultTableModel pm = new DefaultTableModel(new String[]{"ID", "Nombre", "Precio (COP)"}, 0) { public boolean isCellEditable(int r, int c) { return c == 2; } };
        Runnable reload = () -> { pm.setRowCount(0);
            try { for (Opcion o : CatalogoDAO.listar(tipos[tsel.getSelectedIndex()])) pm.addRow(new Object[]{o.id, o.nombre, o.precio}); }
            catch (SQLException ex) { say("No se pudo leer el catálogo:\n" + ex.getMessage()); } };
        reload.run(); tsel.addActionListener(e -> reload.run());
        JTable pt = table(pm); pt.setPreferredScrollableViewportSize(new Dimension(300, 280));
        RP a = card(18);
        a.add(left(L("Catálogo y precios", S(1, 20), PINK))); a.add(gap(8)); a.add(tsel); a.add(gap(8)); a.add(left(tsp(pt))); a.add(gap(10));
        Btn sb = adminBtn("Guardar precios", PINK); sb.setAlignmentX(0); sb.addActionListener(e -> {
            if (pt.isEditing()) pt.getCellEditor().stopCellEditing();
            try {
                Map<Integer, Integer> m = new LinkedHashMap<>();
                for (int i = 0; i < pm.getRowCount(); i++)
                    m.put(Integer.parseInt(pm.getValueAt(i, 0).toString()), Integer.parseInt(pm.getValueAt(i, 2).toString().replaceAll("[^0-9]", "")));
                CatalogoDAO.actualizarPrecios(tipos[tsel.getSelectedIndex()], m); say("Precios actualizados en la base de datos.");
            } catch (NumberFormatException ex) { say("Ingresa solo números."); }
            catch (SQLException ex) { say("No se pudo guardar:\n" + ex.getMessage()); } });
        a.add(sb);

        // ---- pedidos
        DefaultTableModel om = new DefaultTableModel(new String[]{"Pedido", "Cliente", "Total", "Estado", "Repartidor"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        DefaultTableModel rm = new DefaultTableModel(new String[]{"Pedido", "Cliente", "Motivo", "Estado", "Monto", "Atendido por"}, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        JTable ot = table(om), rt = table(rm);
        ot.setPreferredScrollableViewportSize(new Dimension(300, 280)); rt.setPreferredScrollableViewportSize(new Dimension(300, 200));
        int[] wo = {80, 170, 95, 115, 140}, wr = {80, 170, 340, 100, 90, 150};
        for (int i = 0; i < wo.length; i++) ot.getColumnModel().getColumn(i).setPreferredWidth(wo[i]);
        for (int i = 0; i < wr.length; i++) rt.getColumnModel().getColumn(i).setPreferredWidth(wr[i]);
        Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            try {
                peds.clear(); peds.addAll(PedidoDAO.listar(null)); refs.clear(); refs.addAll(ReembolsoDAO.listar());
                om.setRowCount(0); for (PedidoResumen o : peds) om.addRow(new Object[]{o.codigo, o.cliente, money(o.total), o.estado, o.repartidor == null ? "Por asignar" : o.repartidor});
                rm.setRowCount(0); for (Reembolso x : refs) rm.addRow(new Object[]{x.codigo, x.cliente, x.motivo, x.estado, x.monto > 0 ? money(x.monto) : "-", x.atendio});
                sv[0].setText("" + PedidoDAO.contarPedidos()); sv[1].setText(money(PedidoDAO.ventasTotales())); sv[2].setText("" + PedidoDAO.contarClientes());
                sv[3].setText("" + CatalogoDAO.contar(CatalogoDAO.Tipo.SABORES)); sv[4].setText("" + ReembolsoDAO.contarPendientes());
            } catch (SQLException ex) { say("No se pudo leer la base de datos:\n" + ex.getMessage()); }
        };
        refresh[0].run();
        Btn nx = adminBtn("Avanzar estado", PINK), cr = adminBtn("Cambiar repartidor", new Color(60, 66, 110)),
            del = adminBtn("Eliminar pedido", ROJO), clean = adminBtn("Limpiar finalizados", ROJO);
        nx.addActionListener(e -> {
            int r = ot.getSelectedRow(); if (r < 0) { say("Selecciona un pedido."); return; }
            List<String> flow = Arrays.asList("Recibido", "En preparación", "En camino", "Entregado"); PedidoResumen o = peds.get(r); int i = flow.indexOf(o.estado);
            if (i < 0) { say("Este pedido está en estado \"" + o.estado + "\" y no se puede avanzar."); return; }
            if (i == flow.size() - 1) { say("El pedido ya fue entregado."); return; }
            try { PedidoDAO.actualizarEstado(o.idPedido, flow.get(i + 1)); refresh[0].run(); ot.setRowSelectionInterval(r, r); }
            catch (SQLException ex) { say("No se pudo actualizar el estado:\n" + ex.getMessage()); } });
        cr.addActionListener(e -> {
            int r = ot.getSelectedRow(); if (r < 0) { say("Selecciona un pedido."); return; }
            PedidoResumen o = peds.get(r);
            try {
                List<Opcion> reps = UsuarioDAO.listarRepartidores();
                if (reps.isEmpty()) { say("No hay empleados con rol Repartidor en la base de datos."); return; }
                Opcion ini = reps.get(0); for (Opcion x : reps) if (x.id == o.idRepartidor) ini = x;
                Opcion sel = (Opcion) JOptionPane.showInputDialog(frame, "Repartidor para el pedido " + o.codigo + ":", "Cambiar repartidor",
                        JOptionPane.PLAIN_MESSAGE, img("logo", 48, 48), reps.toArray(), ini);
                if (sel == null) return;
                PedidoDAO.asignarRepartidor(o.idPedido, sel.id); refresh[0].run(); ot.setRowSelectionInterval(r, r);
            } catch (SQLException ex) { say("No se pudo cambiar el repartidor:\n" + ex.getMessage()); } });
        del.addActionListener(e -> {
            int r = ot.getSelectedRow(); if (r < 0) { say("Selecciona el pedido que quieres eliminar."); return; }
            PedidoResumen o = peds.get(r);
            if (!confirmar("¿Eliminar el pedido " + o.codigo + " de " + o.cliente + "?\nTambién se borran su detalle, sus reembolsos y los cheesecakes creados para él.\nEsta acción no se puede deshacer.", "Eliminar")) return;
            try { PedidoDAO.eliminar(o.idPedido); refresh[0].run(); }
            catch (SQLException ex) { say("No se pudo eliminar el pedido:\n" + ex.getMessage()); } });
        clean.addActionListener(e -> {
            if (!confirmar("Se eliminarán TODOS los pedidos finalizados (Entregado, Cancelado y Reembolsado) con su detalle y reembolsos.\nLos pedidos en curso y los reembolsos en revisión no se tocan.\n¿Continuar?", "Limpiar")) return;
            try { int n = PedidoDAO.limpiarFinalizados(); refresh[0].run();
                  say(n == 0 ? "No había pedidos finalizados para limpiar." : "Listo: se eliminaron " + n + " pedido(s) finalizado(s) y sus datos relacionados."); }
            catch (SQLException ex) { say("No se pudo limpiar:\n" + ex.getMessage()); } });
        RP b = card(18);
        b.add(left(L("Pedidos", S(1, 20), PINK))); b.add(gap(8)); b.add(left(tsp(ot))); b.add(gap(10));
        Btn vf = adminBtn("Ver factura", new Color(60, 66, 110)), rf = adminBtn("Reenviar factura", new Color(60, 66, 110));
        vf.addActionListener(e -> { int r = ot.getSelectedRow(); if (r < 0) { say("Selecciona un pedido."); return; } trabajoFactura(peds.get(r).codigo, "ver"); });
        rf.addActionListener(e -> { int r = ot.getSelectedRow(); if (r < 0) { say("Selecciona un pedido."); return; } trabajoFactura(peds.get(r).codigo, "enviar"); });
        JPanel bp = left(new JPanel(new GridLayout(3, 2, 8, 8))); bp.setOpaque(false); bp.add(nx); bp.add(cr); bp.add(vf); bp.add(rf); bp.add(del); bp.add(clean); b.add(bp);

        // ---- reembolsos
        Btn ap = adminBtn("Aprobar reembolso", PINK), rj = adminBtn("Rechazar", ROJO);
        ap.addActionListener(e -> {
            int r = rt.getSelectedRow(); if (r < 0) { say("Selecciona una solicitud de reembolso."); return; }
            Reembolso x = refs.get(r);
            if (!ReembolsoDAO.EN_REVISION.equals(x.estado)) { say("Esta solicitud ya fue resuelta (" + x.estado + ")."); return; }
            Object in = JOptionPane.showInputDialog(frame, "Pedido " + x.codigo + " de " + x.cliente + "\nMotivo: " + x.motivo
                    + "\n\nMonto a reembolsar (máximo " + money(x.totalPedido) + "):", "Aprobar reembolso", JOptionPane.PLAIN_MESSAGE, img("logo", 48, 48), null, String.valueOf(x.totalPedido));
            if (in == null) return;
            int m; try { m = Integer.parseInt(in.toString().replaceAll("[^0-9]", "")); } catch (NumberFormatException ex) { say("Escribe solo números."); return; }
            try { ReembolsoDAO.resolver(x.idDevolucion, user.id, true, m); refresh[0].run(); say("Reembolso aprobado por " + money(m) + "."); }
            catch (SQLException ex) { say(ex.getMessage()); } });
        rj.addActionListener(e -> {
            int r = rt.getSelectedRow(); if (r < 0) { say("Selecciona una solicitud de reembolso."); return; }
            Reembolso x = refs.get(r);
            if (!ReembolsoDAO.EN_REVISION.equals(x.estado)) { say("Esta solicitud ya fue resuelta (" + x.estado + ")."); return; }
            if (!confirmar("¿Rechazar el reembolso del pedido " + x.codigo + " de " + x.cliente + "?", "Rechazar")) return;
            try { ReembolsoDAO.resolver(x.idDevolucion, user.id, false, 0); refresh[0].run(); }
            catch (SQLException ex) { say(ex.getMessage()); } });
        RP c = card(18); c.setAlignmentX(0);
        c.add(left(L("Reembolsos", S(1, 20), PINK))); c.add(gap(4));
        c.add(left(L("Las solicitudes en revisión aparecen primero. Selecciona una y apruébala (con el monto) o recházala.", F(0, 12), MUTED))); c.add(gap(8));
        c.add(left(tsp(rt))); c.add(gap(10));
        JPanel cp = left(new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0))); cp.setOpaque(false); cp.add(ap); cp.add(rj); c.add(cp);

        JPanel grid = left(new JPanel(new GridLayout(1, 2, 16, 0))); grid.setOpaque(false); grid.add(a); grid.add(b);
        JPanel body = col(); body.setBorder(new EmptyBorder(6, 30, 26, 30));
        body.add(stats); body.add(gap(12)); body.add(grid); body.add(gap(16)); body.add(c);
        JPanel w = new JPanel(new BorderLayout()); w.setOpaque(false); w.add(body, BorderLayout.NORTH); p.add(sp(w), BorderLayout.CENTER);
    }

    // ---------- arranque ----------
    /** Fondo de cada pantalla: azul noche con resplandores de neón en las esquinas. */
    static class Bg extends JPanel {
        Bg() { super(new BorderLayout()); setOpaque(true); setBackground(BG); }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); Graphics2D g2 = (Graphics2D) g.create(); int w = getWidth(), h = getHeight(); float r = Math.max(w, h) * 0.65f;
            g2.setPaint(new RadialGradientPaint(new Point2D.Float(0, 0), r, new float[]{0f, 1f}, new Color[]{new Color(255, 77, 166, 48), new Color(255, 77, 166, 0)})); g2.fillRect(0, 0, w, h);
            g2.setPaint(new RadialGradientPaint(new Point2D.Float(w, h), r, new float[]{0f, 1f}, new Color[]{new Color(56, 225, 255, 40), new Color(56, 225, 255, 0)})); g2.fillRect(0, 0, w, h);
            g2.setPaint(new RadialGradientPaint(new Point2D.Float(w * 0.75f, 0), r * 0.6f, new float[]{0f, 1f}, new Color[]{new Color(139, 92, 255, 34), new Color(139, 92, 255, 0)})); g2.fillRect(0, 0, w, h);
            g2.dispose();
        }
    }
    /** Barra superior con degradado y línea de neón inferior. */
    static class Bar extends JPanel {
        Bar() { super(new BorderLayout()); setOpaque(true); }
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create(); int w = getWidth(), h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, new Color(9, 11, 22), w, 0, new Color(20, 14, 40))); g2.fillRect(0, 0, w, h);
            g2.setPaint(new GradientPaint(0, 0, new Color(255, 77, 166, 190), w, 0, new Color(56, 225, 255, 190))); g2.fillRect(0, h - 2, w, 2); g2.dispose();
        }
    }
    static void reg(String key, String label, Consumer1 fn, JPanel bar) {
        JPanel v = new Bg(); views.put(key, v); content.add(v, key);
        builders.put(key, () -> { v.removeAll(); fn.build(v); v.revalidate(); v.repaint(); });
        Btn b = new Btn(label, WHITE, true); b.addActionListener(e -> go(key)); nav.put(key, b); bar.add(b);
    }
    interface Consumer1 { void build(JPanel p); }

    public static void main(String[] args) { SwingUtilities.invokeLater(Main::start); }
    static JPanel buildUI() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception e) { }
        UIManager.put("Panel.background", BG); UIManager.put("OptionPane.background", BG); UIManager.put("OptionPane.messageForeground", WHITE);
        UIManager.put("OptionPane.messageFont", F(0, 14)); UIManager.put("OptionPane.buttonFont", F(1, 13));
        UIManager.put("Button.background", new Color(30, 36, 66)); UIManager.put("Button.foreground", WHITE);
        UIManager.put("ComboBox.background", FIELD); UIManager.put("ComboBox.foreground", WHITE);
        UIManager.put("ComboBox.selectionBackground", new Color(190, 45, 125)); UIManager.put("ComboBox.selectionForeground", WHITE);
        UIManager.put("ComboBox.buttonBackground", new Color(30, 36, 66));
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(BG);
        JPanel top = new Bar(); top.setBorder(new EmptyBorder(8, 20, 10, 14));
        JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0)); brand.setOpaque(false); brand.add(new JLabel(img("logo", 52, 52)));
        JPanel bt = col(); JLabel w1 = new GL("ROMALE", S(1, 22)); w1.setAlignmentX(0); JLabel w2 = L("D E S S E R T S", F(1, 10), GOLD); w2.setAlignmentX(0);
        bt.add(w1); bt.add(w2); brand.add(bt); top.add(brand, BorderLayout.WEST);
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 10)); bar.setOpaque(false); top.add(bar, BorderLayout.EAST);
        reg("catalog", "Catálogo", Main::catalog, bar); reg("custom", "Personalizar", Main::custom, bar); reg("cart", "Carrito", Main::cartView, bar);
        reg("orders", "Mis pedidos", Main::ordersView, bar); reg("login", "Login", Main::login, bar); reg("register", "Registro", Main::register, bar);
        reg("payment", "Pago", Main::payment, bar); reg("admin", "Admin", Main::admin, bar);
        root.add(top, BorderLayout.NORTH); root.add(content, BorderLayout.CENTER);
        go("catalog"); return root;
    }
    static void start() {
        try { Esquema.asegurar(); } catch (Exception e) { /* si no hay conexión se avisa más abajo */ }
        frame = new JFrame("Romale Desserts"); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); frame.setIconImage(img("logo", 64, 64).getImage());
        frame.setContentPane(buildUI());
        frame.setSize(1300, 820); frame.setMinimumSize(new Dimension(1180, 720)); frame.setLocationRelativeTo(null); frame.setVisible(true);
        String err = newpackage.Conexion.probar();
        if (err != null) say("No hay conexión con la base de datos basededatosrd.\n\n" + err
                + "\n\nRevisa que MySQL esté encendido y los datos de newpackage/Conexion.java.");
    }
}
