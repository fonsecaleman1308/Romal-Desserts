@echo off
java -jar dist\RomaleDesserts3.0.jar
pause
