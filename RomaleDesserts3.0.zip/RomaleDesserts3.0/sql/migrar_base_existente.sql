-- ============================================================
-- Para quien YA tiene la base basededatosrd con datos y no quiere borrarla.
-- No elimina nada. Es seguro ejecutarlo más de una vez.
--  1) Agranda la columna de contraseñas y cifra las que aún estén en texto plano.
--  2) Agrega el sabor Arándanos si todavía no existe.
-- (La columna pedidos.id_repartidor la crea la propia aplicación al abrirse.)
-- ============================================================
USE basededatosrd;

ALTER TABLE clientes          MODIFY contrasena VARCHAR(100) NOT NULL;
ALTER TABLE clientes_internos MODIFY contrasena VARCHAR(100) NOT NULL;

UPDATE clientes          SET contrasena = SHA2(contrasena, 256) WHERE CHAR_LENGTH(contrasena) < 64;
UPDATE clientes_internos SET contrasena = SHA2(contrasena, 256) WHERE CHAR_LENGTH(contrasena) < 64;

INSERT INTO sabores (nombre, descripcion, precio_adicional)
SELECT 'Arándanos', 'Cheesecake con salsa y arándanos frescos', 2000
WHERE NOT EXISTS (SELECT 1 FROM sabores WHERE nombre = 'Arándanos');
