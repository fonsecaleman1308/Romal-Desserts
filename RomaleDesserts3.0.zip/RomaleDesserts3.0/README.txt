================================================================
 ROMALE DESSERTS 3.0  -  Java Swing + MySQL (base basededatosrd)
================================================================

PASOS PARA PONERLO A FUNCIONAR
 1. Base de datos: en phpMyAdmin (pestaña SQL) pega y ejecuta TODO el archivo
        sql/basededatosrd_completa.sql
    (crea la base, las tablas y los datos de ejemplo. Ojo: borra la base basededatosrd si ya existia.
     Si ya tienes datos que quieres conservar, ejecuta en su lugar sql/migrar_base_existente.sql).
 2. Driver de MySQL: copia  mysql-connector-java-8.0.17.jar  a la carpeta lib/  (ver lib/LEEME.txt).
 3. Conexion: abre src/newpackage/Conexion.java y revisa USUARIO y CLAVE de tu MySQL
    (XAMPP normalmente: root y clave vacia "").
 4. NetBeans: Archivo > Abrir proyecto > selecciona la carpeta RomaleDesserts3.0.
    Prueba la conexion: clic derecho en newpackage/PruebaConexion.java > Run File.
    Ejecuta el proyecto con F6.
 5. (Opcional) Factura por correo: abre src/servicios/Correo.java y llena USUARIO y CLAVE
    (en Gmail: "Contrasena de aplicacion", requiere verificacion en 2 pasos).

USUARIOS DE EJEMPLO
 - Administrador: admin / admin123
 - Clientes: lmartinez / clave101, crodriguez / clave102, vgomez / clave103 ... (hasta clave115)
 - Para crear un administrador desde el registro: elegir "Administrador" y escribir el codigo ROMALE2026
   (se cambia en src/datos/UsuarioDAO.java, constante CODIGO_ADMIN).

QUE HACE LA APLICACION
 - Catalogo: carrusel de sabores con imagenes cambiantes y tarjetas con efecto. Sabores: Oreo, Maracuya,
   Frutos rojos, Limon y Arandanos (lista en src/datos/CatalogoDAO.java).
 - Personalizar: tamaño, sabor, extras y toppings con vista previa y precio animado.
 - Registro/login de clientes y administradores (contrasenas cifradas SHA-256), carrito y pago simulado.
 - Cada pedido se guarda en la base y se asigna al repartidor con menos pedidos activos.
 - Mis pedidos: estado con barra de progreso, repartidor, direccion, reembolsos y factura.
 - Reembolsos: el cliente los solicita; Atencion al cliente los recibe; el administrador los aprueba o rechaza.
 - Factura PDF: se genera al pagar (carpeta facturas/) y se envia al correo del cliente.
 - Panel de administrador: editar precios, avanzar estado, cambiar repartidor, eliminar pedidos,
   limpiar pedidos finalizados, resolver reembolsos, ver/reenviar facturas.

ESTRUCTURA DEL PROYECTO
 src/newpackage   Conexion (datos de conexion) y PruebaConexion
 src/datos        Acceso a la base: UsuarioDAO, CatalogoDAO, PedidoDAO, ReembolsoDAO, FacturaDAO, Esquema, Seguridad
 src/entidades    Usuario, Opcion, ItemCarrito, PedidoResumen, Reembolso, Factura
 src/servicios    FacturaPDF (genera el PDF), Correo (envio SMTP), FacturaServicio
 src/romale       Main (interfaz). frmservidor es una plantilla sin usar.
 sql/             basededatosrd_completa.sql  y  migrar_base_existente.sql
 lib/             aqui va el driver de MySQL
 CODIGO_COMPLETO.txt (en la entrega) reune todo el codigo fuente en un solo archivo para leerlo.

NOTAS
 - El medio de pago es simulado y no se guarda (la base no tiene columna para eso).
 - La factura es un comprobante de compra; no es factura electronica valida ante la DIAN.
 - No compartas Correo.java ni Conexion.java si tienen tus claves.
