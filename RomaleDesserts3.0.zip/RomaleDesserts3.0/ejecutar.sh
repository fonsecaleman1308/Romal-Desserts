#!/bin/sh
cd "$(dirname "$0")"
java -jar dist/RomaleDesserts3.0.jar
