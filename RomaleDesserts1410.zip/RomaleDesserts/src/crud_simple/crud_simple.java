/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package crud_simple;
import java.util.List;
/**
 *
 * @author prestamo
 */
public interface crud_simple<T> {
    public List<T> listar(String texto);
    public boolean insertar(T objeto);
    public boolean actualizar(T objeto);
    public boolean desactivar(int id);
    public boolean activar(int id);
    public int total();
    
}
